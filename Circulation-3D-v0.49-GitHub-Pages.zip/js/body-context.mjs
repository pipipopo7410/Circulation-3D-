/* V0.49 — continuous, softly rendered body envelope. Not an anatomical 3D scan.
   Coordinates follow the verified vascular model bounds (x: ±0.332, y: 0.003–1.701).
   This contextual outline intentionally has NO joint spheres or detached capsules. */
import * as THREE from 'three';
const outlineColor=0x86a5b7;
const right=[];
function start(x,y){right.push(new THREE.Vector2(x,y));}
function cubic(x1,y1,x2,y2,x3,y3){
 const p=right[right.length-1];
 const curve=new THREE.CubicBezierCurve(p,new THREE.Vector2(x1,y1),new THREE.Vector2(x2,y2),new THREE.Vector2(x3,y3));
 right.push(...curve.getPoints(10).slice(1));
}
// Draw down the viewer's right side: crown -> neck -> shoulders -> arm -> waist
// -> thigh -> foot -> inner leg -> crotch. Reflect to make the left side.
start(0,1.730);
cubic(.098,1.727,.146,1.670,.145,1.610);
cubic(.147,1.554,.115,1.517,.070,1.495);
cubic(.066,1.469,.066,1.455,.078,1.449);
cubic(.147,1.439,.257,1.410,.286,1.360);
cubic(.318,1.296,.360,1.100,.390,.958);
cubic(.411,.852,.451,.785,.442,.752);
cubic(.451,.719,.423,.700,.408,.715);
cubic(.305,.750,.255,.843,.218,.942);
cubic(.220,1.105,.252,1.219,.262,1.287);
cubic(.243,1.271,.235,1.228,.232,1.188);
cubic(.231,1.049,.191,.902,.220,.803);
cubic(.247,.705,.259,.634,.223,.544);
cubic(.199,.446,.193,.331,.181,.198);
cubic(.172,.118,.167,.068,.165,.041);
cubic(.214,.028,.232,.002,.215,-.017);
cubic(.201,-.033,.126,-.033,.080,-.021);
cubic(.058,-.004,.052,.035,.052,.080);
cubic(.050,.213,.050,.350,.050,.441);
cubic(.047,.562,.033,.658,.018,.705);
cubic(.010,.710,.005,.711,0,.710);
const all=[...right,...right.slice(0,-1).reverse().map(p=>new THREE.Vector2(-p.x,p.y))];
const outlineShape=new THREE.Shape();outlineShape.moveTo(all[0].x,all[0].y);
all.slice(1).forEach(p=>outlineShape.lineTo(p.x,p.y));outlineShape.closePath();
export function getBodyContour2D(){return all.map(p=>[p.x,p.y]);}
export function buildBodyContext(){
 const body=new THREE.Group();body.name='淡色人體定位外框';
 const geo=new THREE.ExtrudeGeometry(outlineShape,{depth:.29,bevelEnabled:false,steps:1,curveSegments:4});
 geo.translate(0,0,-.144);
 const surface=new THREE.Mesh(geo,new THREE.MeshBasicMaterial({color:0xb6d2db,transparent:true,opacity:.010,side:THREE.DoubleSide,depthWrite:false,depthTest:true}));
 surface.name='連續人體外形（極淡）';surface.renderOrder=-20;surface.userData.contextOnly=true;body.add(surface);
 for(const z of [-.148,.149]){
  const pts=all.map(p=>new THREE.Vector3(p.x,p.y,z));
  const rim=new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(pts),new THREE.LineBasicMaterial({color:outlineColor,transparent:true,opacity:.18,depthWrite:false,depthTest:true}));
  rim.name='單一連續人體輪廓';rim.renderOrder=-18;rim.userData.contextOnly=true;body.add(rim);
 }
 body.userData.educationalContext=true;
 body.userData.bounds={xmin:-.451,xmax:.451,ymin:-.033,ymax:1.730};
 return body;
}
