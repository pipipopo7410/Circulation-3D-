/* V0.51 classroom route composer — directional circulation, not patient anatomy.
 * True decoded centreline stages are preserved. Missing microvascular connections
 * are marked as educational schematics; no imaginary tubes are added to the GLB.
 * A === B means a full pass through the pulmonary AND systemic circuits.
 */
import {expandedPulmonaryRoute} from './pulmonary-network.mjs';
export const REGION_CHOICES = Object.freeze([
 ['heart','心臟'],['lung','肺臟'],['head','頭部'],
 ['left_arm','左手臂'],['right_arm','右手臂'],
 ['left_leg','左下肢'],['right_leg','右下肢'],['kidney','腎臟']
]);
const POS={
 rightHeart:[-.016618,1.340799,.017772],
 leftHeart:[.019547,1.316422,.019323],
 arch:[.00583,1.36022,.028574],
 head:[-.001,1.657,.015],
 kidney:[-.091,1.096,-.028],
 right_leg:[-.116,.475,-.021],
};
const regionTitles=Object.fromEntries(REGION_CHOICES);
const dist=(a,b)=>Math.hypot(...a.map((n,i)=>n-b[i]));
const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
const copyPoint=p=>[...p];
const end=s=>s.points.at(-1);
const start=s=>s.points[0];
function conceptual(from,to,oxygen,title,points=[from,to],system='concept-bridge'){
 const clean=[copyPoint(from),...points.slice(1,-1).map(copyPoint),copyPoint(to)];
 const length=clean.reduce((sum,p,i)=>i?sum+dist(clean[i-1],p):0,0);
 return {kind:'schematic',title,oxygen,teachingSystem:system,points:clean,
  radiusModelUnit:.0027,durationMs:clamp(length*4800,850,4300),
  source:'教學簡化示意；非原始血管中心線',educationalApproximation:true};
}
function exchange(from,to,label){
 const middle=from.map((v,i)=>(v+to[i])/2);
 return {...conceptual(from,to,'high-to-low',`${label}｜組織交換`,[from,middle,to],'tissue-exchange'),
  durationMs:1850,tissue:{center:middle,radius:.009}};
}
function realRoute(paths,slug,title,oxygen){
 const route=paths?.routes?.[slug];if(!route?.points?.length)return null;
 return {kind:'real',title,oxygen,points:route.points.map(copyPoint),
  meshes:route.segments?.map(s=>s.name)||[],
  durationMs:clamp(route.points.length*26,1700,4100),source:'解碼 GLB 驗證中心線'};
}
function addTo(stages,part){
 const pieces=Array.isArray(part)?part:[part];
 for(const stage of pieces){
  if(!stage?.points?.length)throw Error('Missing route segment');
  const prev=stages.at(-1);
  if(prev && dist(end(prev),start(stage))>.0035){
   stages.push(conceptual(end(prev),start(stage),stage.oxygen==='high'?'high':'low','兩條血管間的教學連接'));
  }
  stages.push(stage);
 }
}
// GLB-proven central vessels plus clearly marked extended lung-interior guides.
function lungToLeftHeart(cp){return expandedPulmonaryRoute(cp,{part:'from-lung'});}
function rightHeartToLung(cp){return expandedPulmonaryRoute(cp,{part:'to-lung'});}
function rightHeartToLeftHeart(cp){return expandedPulmonaryRoute(cp,{part:'all'});}

const REGIONS={
 head:{label:'頭部',artery:[POS.arch,[.015,1.49,-.009],[.010,1.589,-.009],POS.head],
  vein:[[-.022,1.640,.015],[-.037,1.489,.018],POS.rightHeart]},
 right_leg:{label:'右下肢',artery:[POS.arch,[.012,1.215,-.018],[-.078,.925,-.030],POS.right_leg],
  vein:[[-.131,.481,.013],[-.106,.933,.021],[-.014,1.262,.020],POS.rightHeart]},
 kidney:{label:'腎臟',artery:[POS.arch,[.002,1.235,-.010],[-.036,1.115,-.024],POS.kidney],
  vein:[[-.077,1.098,.011],[-.014,1.220,.014],POS.rightHeart]}
};
export function buildRegionRoute(from,to,context){
 const {cardiopulmonary,systemicArm,verifiedPaths}=context||{};
 const cp=cardiopulmonary?.stages,sys=systemicArm?.stages;
 if(!regionTitles[from]||!regionTitles[to])throw Error('未知的器官選項');
 if(!cp?.length||!sys?.length||!verifiedPaths?.routes)throw Error('血流資料仍在載入');
 const all=[], add=p=>addTo(all,p);
 const outbound=which=>{
  if(which==='left_arm'){add(sys.slice(0,5));return;}
  add(sys[0]);
  if(which==='right_arm'){
   const a=realRoute(verifiedPaths,'right-arm-artery','右手臂動脈','high');
   if(!a)throw Error('右臂動脈中心線未載入');
   add(a);const v=realRoute(verifiedPaths,'right-arm-vein','右手臂靜脈','low');
   const exchangeEnd=start(v);
   add(exchange(end(a),exchangeEnd,'右手臂'));return;
  }
  if(which==='left_leg'){
   const a=realRoute(verifiedPaths,'left-leg-artery-proximal','左下肢動脈','high');
   const v=realRoute(verifiedPaths,'left-leg-vein','左下肢靜脈','low');
   if(!a||!v)throw Error('左下肢血管中心線未載入');
   add(a);add(exchange(end(a),start(v),'左下肢'));return;
  }
  const data=REGIONS[which];if(!data)throw Error('缺少位置資料');
  add(conceptual(end(sys[0]),data.artery.at(-1),'high',`${data.label}｜供血（示意）`,[end(sys[0]),...data.artery.slice(1)]));
  add(exchange(data.artery.at(-1),data.vein[0],data.label));
 };
 const inbound=which=>{
  if(which==='left_arm'){add(sys.slice(5,9));return;}
  if(which==='right_arm'){
   add(realRoute(verifiedPaths,'right-arm-vein','右手臂靜脈','low'));
   add(cp[0]);return;
  }
  if(which==='left_leg'){
   add(realRoute(verifiedPaths,'left-leg-vein','左下肢靜脈','low'));
   add(conceptual(end(all.at(-1)),POS.rightHeart,'low','下腔靜脈回心（示意）',
    [end(all.at(-1)),[-.016,1.270,.012],POS.rightHeart]));return;
  }
  const data=REGIONS[which];if(!data)throw Error('缺少位置資料');
  // Generic schematic starts at the endpoint of the same region's exchange stage.
  add(conceptual(end(all.at(-1)),POS.rightHeart,'low',`${data.label}｜靜脈回流（示意）`,
   [end(all.at(-1)),...data.vein.slice(1)]));
 };
 const outboundFor=which=>{
  outbound(which);
 };
 // Regions represent a capillary-exchange location. First return venously
 // to right heart, then visit lungs, then leave left heart arterially.
 if(from==='heart'){
  if(to==='heart'){
   add(rightHeartToLeftHeart(cp));outboundFor('left_arm');inbound('left_arm');
  }else if(to==='lung')add(rightHeartToLung(cp));
  else outboundFor(to);
 }else if(from==='lung'){
  add(lungToLeftHeart(cp));
  if(to==='heart'){} // ends in left ventricle
  else if(to==='lung'){
   outboundFor('left_arm');inbound('left_arm');add(rightHeartToLung(cp));
  }else outboundFor(to);
 }else{
  // An organ-origin route begins at its venous outflow (post-exchange).
  if(from==='left_arm'){inbound(from);}
  else if(from==='right_arm'){ // first actual right-arm venous segment
   const v=realRoute(verifiedPaths,'right-arm-vein','右手臂靜脈','low');
   add(v);add(cp[0]);
  }else if(from==='left_leg'){
   add(realRoute(verifiedPaths,'left-leg-vein','左下肢靜脈','low'));
   add(conceptual(end(all.at(-1)),POS.rightHeart,'low','下腔靜脈回流（示意）',[end(all.at(-1)),[-.016,1.27,.014],POS.rightHeart]));
  }else{
   const data=REGIONS[from];add(conceptual(data.vein[0],POS.rightHeart,'low',`${data.label}｜回心（示意）`,data.vein));
  }
  if(to==='heart'){} // ends at right heart
  else if(to==='lung')add(rightHeartToLung(cp));
  else{add(rightHeartToLeftHeart(cp));outboundFor(to);}
 }
 if(!all.length)throw Error('Empty playback');
 let gap=0;for(let i=1;i<all.length;i++)gap=Math.max(gap,dist(end(all[i-1]),start(all[i])));
 const schematicCount=all.filter(x=>x.educationalApproximation).length;
 const exchanges=all.filter(x=>x.teachingSystem==='lung-exchange').length;
 const tissue=all.filter(x=>['arm-exchange','tissue-exchange'].includes(x.teachingSystem)).length;
 return {title:`${regionTitles[from]} → ${regionTitles[to]}`,from,to,stages:all,
  hasConceptual:schemaCount(schematicCount,all),schematicCount,maxGap:gap,
  isLoop:from===to,hasPulmonaryExchange:exchanges>0,hasTissueExchange:tissue>0};
}
function schemaCount(count,all){return count>0||all.some(x=>x.kind==='schematic'||x.kind==='simplified');}
