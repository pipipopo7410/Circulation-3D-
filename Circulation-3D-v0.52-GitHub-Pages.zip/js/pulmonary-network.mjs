/* V0.52 — classroom pulmonary route extensions, not decoded anatomy.
 * The actual pulmonary trunk, right pulmonary artery and right superior
 * pulmonary vein remain original, unmodified GLB centrelines. Only the
 * missing lung-interior connection is drawn as distinguishable dashed guides.
 * A SINGLE blood particle visits ONE lung, not both lungs in sequence.
 */
const clone=p=>p.map(Number);
const d=(a,b)=>Math.hypot(...a.map((v,i)=>v-b[i]));
const len=p=>p.slice(1).reduce((v,q,i)=>v+d(p[i],q),0);
export const RIGHT_LUNG_IN=[[-.034,1.331,-.007],[-.058,1.332,-.017],[-.080,1.344,-.026],[-.102,1.361,-.029],[-.125,1.366,-.020]];
export const RIGHT_LUNG_CAPILLARY=[[-.125,1.366,-.020],[-.134,1.352,-.029],[-.140,1.333,-.038],[-.138,1.314,-.040],[-.151,1.293,-.032],[-.126,1.278,-.021],[-.106,1.284,-.012]];
export const RIGHT_LUNG_OUT=[[-.106,1.284,-.012],[-.088,1.299,-.001],[-.074,1.318,.011],[-.061,1.331,.013],[-.044,1.338,.002]];
// The opposite branch is visible for spatial understanding but is not part
// of the yellow particle's route. It must NEVER look like sequential travel
// through the two lungs.
export const LEFT_LUNG_IN=[[.029,1.345,.030],[.045,1.349,.004],[.066,1.362,-.015],[.099,1.359,-.023],[.124,1.346,-.024]];
export const LEFT_LUNG_CAPILLARY=[[.124,1.346,-.024],[.141,1.324,-.027],[.143,1.302,-.032],[.130,1.283,-.026],[.106,1.290,-.016]];
export const LEFT_LUNG_OUT=[[.106,1.290,-.016],[.084,1.309,.000],[.056,1.326,.017],[.026,1.334,.026]];
function stage(points,{title,oxygen,system,durationMs,alveolus}={}){
 const p=points.map(clone); const x={kind:'schematic',title,oxygen,
  teachingSystem:system,points:p,durationMs,
  radiusModelUnit:.0031,educationalApproximation:true,
  source:'肺內延伸教學示意，非解碼 GLB 中心線'};
 if(alveolus)x.alveolus=alveolus;
 return x;
}
export function makePulmonaryBridge(cardiopulmonaryStages){
 const cp=cardiopulmonaryStages;
 if(!Array.isArray(cp)||cp.length<8)throw Error('Missing verified heart-lung vessels');
 const realArteryEnd=cp[4].points.at(-1);
 const realVeinStart=cp[6].points[0];
 if(d(realArteryEnd,RIGHT_LUNG_IN[0])>.004 || d(realVeinStart,RIGHT_LUNG_OUT.at(-1))>.004)
  throw Error('Pulmonary guide mismatches the original GLB centreline');
 return [
  stage([realArteryEnd,...RIGHT_LUNG_IN.slice(1)],{title:'進入右肺｜肺動脈分支示意',oxygen:'low',system:'pulmonary-artery-extension',durationMs:2700}),
  stage(RIGHT_LUNG_CAPILLARY,{title:'肺臟內微血管｜氣體交換示意',oxygen:'transition',system:'lung-exchange',durationMs:3800,
   alveolus:{center:[-.139,1.323,-.026],radius:.009}}),
  stage([...RIGHT_LUNG_OUT.slice(0,-1),realVeinStart],{title:'由肺回到心臟｜肺靜脈分支示意',oxygen:'high',system:'pulmonary-vein-extension',durationMs:2700})
 ];
}
export function expandedPulmonaryRoute(cp,{part='all'}={}){
 const extensions=makePulmonaryBridge(cp);
 if(part==='to-lung')return [...cp.slice(1,5),...extensions.slice(0,2)];
 if(part==='from-lung')return [extensions[2],...cp.slice(6,8)];
 if(part==='all')return [...cp.slice(1,5),...extensions,...cp.slice(6,8)];
 throw Error('Unsupported pulmonary stage section');
}
export function pulmonaryGuideData(){
 const out=[
  {name:'右肺動脈延伸（示意）',oxygen:'low',side:'right',points:RIGHT_LUNG_IN},
  {name:'右肺微血管（示意）',oxygen:'transition',side:'right',points:RIGHT_LUNG_CAPILLARY},
  {name:'右肺靜脈延伸（示意）',oxygen:'high',side:'right',points:RIGHT_LUNG_OUT},
  {name:'左肺動脈分支（示意）',oxygen:'low',side:'left',points:LEFT_LUNG_IN},
  {name:'左肺微血管（示意）',oxygen:'transition',side:'left',points:LEFT_LUNG_CAPILLARY},
  {name:'左肺靜脈分支（示意）',oxygen:'high',side:'left',points:LEFT_LUNG_OUT},
  // Small complementary branches give each lung a readable vascular spread.
  // These branches are NOT traversed by the moving dot; no false serial path.
  {name:'右肺上葉動脈支（示意）',oxygen:'low',side:'right',points:[[-.080,1.344,-.026],[-.089,1.374,-.028],[-.095,1.399,-.024]]},
  {name:'右肺上葉靜脈支（示意）',oxygen:'high',side:'right',points:[[-.096,1.397,-.020],[-.084,1.365,.003],[-.061,1.331,.013]]},
  {name:'右肺下葉動脈支（示意）',oxygen:'low',side:'right',points:[[-.102,1.361,-.029],[-.110,1.289,-.038],[-.118,1.245,-.025]]},
  {name:'右肺下葉靜脈支（示意）',oxygen:'high',side:'right',points:[[-.118,1.245,-.019],[-.103,1.272,-.006],[-.074,1.318,.011]]},
  {name:'左肺上葉動脈支（示意）',oxygen:'low',side:'left',points:[[.066,1.362,-.015],[.089,1.378,-.023],[.103,1.401,-.020]]},
  {name:'左肺上葉靜脈支（示意）',oxygen:'high',side:'left',points:[[.101,1.400,-.014],[.081,1.363,.005],[.056,1.326,.017]]},
  {name:'左肺下葉動脈支（示意）',oxygen:'low',side:'left',points:[[.099,1.359,-.023],[.113,1.293,-.035],[.124,1.246,-.026]]},
  {name:'左肺下葉靜脈支（示意）',oxygen:'high',side:'left',points:[[.125,1.246,-.018],[.109,1.275,-.001],[.084,1.309,.000]]},
 ];
 return out.map(x=>({...x,points:x.points.map(clone),length:len(x.points),educationalApproximation:true}));
}
