/* V0.48 classroom camera-safe real-anatomy viewer. MIT Three.js runtime, local Draco-compressed GLBs.
   Models are licensed separately; see ATTRIBUTION.md. */
import * as THREE from 'three';
import {prepareTeachingTimeline,positionOnStage,advanceTeachingTimeline} from './flow-timeline.mjs';
import {protectCameraPose,isWithinBodyEnvelope} from './camera-limits.mjs';
import {buildOrganShells,setOrganShellMode,setOrganShellFocus,nextOrganMode,ORGAN_MODE_LABELS} from './organ-shells.mjs';
import {positionVisibleLabels} from './organ-label-layout.mjs';
import {cornersFromBounds,centerOfBounds,fitDistanceForView,normalizedViewBounds} from './view-framing.mjs';
import {teachingForeground,teachingVesselStyle} from './lesson-visibility.mjs';
import {createTapGate,snapshotExploration,resolveExplorationFilter,restoreCameraPoseSafely} from './classroom-input.mjs';
import {buildBodyContext} from './body-context.mjs';
window.__viewerBootState='starting';
if(window.__viewerDiagnostics)window.__viewerDiagnostics.moduleImported=true;
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {DRACOLoader} from 'three/addons/loaders/DRACOLoader.js';

const $=id=>document.getElementById(id);
const sceneEl=$('scene'), viewEl=$('view');
let renderer, scene, camera, controls, pending=false;
const vesselGroup=new THREE.Group(), vessels=[], byName=new Map(), byType={arteries:[],veins:[]};
let bodyContext=null, organShells=null, organPreferred='translucent', organAuto=false;
const organBtn=$('organBtn');
function showOrganMode(mode,{manual=false}={}){
 if(manual){organPreferred=mode;organAuto=false;if(organShells)setOrganShellFocus(organShells,'none');}
 if(organShells)setOrganShellMode(organShells,mode);
 // Teacher override must immediately restore depth-correct rendering for
 // solid/hidden shells, even when the current lesson stage stays unchanged.
 if(stagedFlow&&organShells){spotlightAt=-1;highlightTeachingStage(stagedFlow[stagedAt]);}
 if(organBtn){organBtn.textContent=ORGAN_MODE_LABELS[mode];organBtn.dataset.mode=mode;organBtn.setAttribute('aria-label',ORGAN_MODE_LABELS[mode]+'；點擊切換器官顯示');}
 invalidate();
}
function restoreOrganMode(){if(organAuto){organAuto=false;showOrganMode(organPreferred);}}
function showOrgansForPulmonaryLesson(){
 if(!organShells)return;
 organAuto=true;showOrganMode('translucent');
}

let cardiopulmonary=null, systemicArm=null, stagedFlow=null, stagedTimeline=null, stagedAt=0, stagedMs=0, teachingTube=null, teachingSchematic=null, stageGuide=null, spotlightAt=-1, cueAt=-1, activeLessonNote='';
let verifiedPaths=null, flowMarker=null, flowCurve=null, flowSegments=[], flowTotal=0, flowTime=0, flowLast=0, flowFrame=0, flowPlaying=false, flowSlug=null;
let routeUiAt=-1;
let levels=null, levelMap={arteries:new Map(),veins:new Map()}, filterType='all', level=0, selected=null, currentRoute=null, routeAt=0, toastTimer=0, suggestedPlan=null;
const levelsText=['完整','主要','核心'];
const boundsMid=new THREE.Vector3(0.0000000,0.8524569,0.0117921);
const modelHeight=1.697985;
let cameraGuardBusy=false, lessonCameraFitDistance=0, activeFitCorners=null, exploreBeforeDemo=null;
const cameraMode=()=>stagedFlow?'lesson':flowSlug?'route':'explore';
function saveExploreViewBeforeDemo(){
 // Entering one lesson must not destroy the user's previous viewpoint or tier.
 if(!exploreBeforeDemo&&camera&&controls)exploreBeforeDemo=snapshotExploration({
  camera:camera.position.toArray(),target:controls.target.toArray(),level,filterType
 });
}
function restoreExploreViewAfterDemo(){
 const saved=exploreBeforeDemo;exploreBeforeDemo=null;
 if(!saved||!controls)return false;
 const originalFilter=resolveExplorationFilter(saved);
 if(originalFilter){level=originalFilter.level;filterType=originalFilter.filterType;updateFilterButtons();}
 // V0.47: OrbitControls damping can retain rotation/pan impulses after a
 // gesture or teaching camera transition. Drain them *before* restoring the
 // teacher's saved view, otherwise the restored camera drifts one more step.
 restoreCameraPoseSafely({controls,camera,pose:saved,minDistance:1.88});
 enforceCameraLimits();
 applyFilters();return true;
}
function flagManualFilter(){if(exploreBeforeDemo)exploreBeforeDemo.manuallyChangedFilter=true;}
function enforceCameraLimits(){
 if(cameraGuardBusy||!camera||!controls)return;
 const mode=cameraMode();
 const lessonFit=mode==='lesson'?lessonCameraFitDistance:0;
 const result=protectCameraPose(camera.position.toArray(),controls.target.toArray(),{mode,lessonFit});
 controls.minDistance=result.minimumDistance;
 if(result.restricted){
  cameraGuardBusy=true;
  controls.target.set(...result.target);camera.position.set(...result.camera);
  controls.update();cameraGuardBusy=false;
 }
}

const layerBtn=$('layerBtn');
const sizeLabel=$('modelCount');
const loadTitle=$('loadingTitle'), loadDetail=$('loadingDetail'), loadFill=$('loadingFill');
const screenMsg=$('infoTag');
const lessonCue=$('lessonCue'), lessonCueName=$('lessonCueName'), lessonCueOxygen=$('lessonCueOxygen');
function notify(s){const n=$('toast');n.textContent=s;n.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>n.hidden=true,2100)}
function errorStage(err){window.__viewerBootState='failed';if(window.__viewerDiagnostics)window.__viewerDiagnostics.error=String(err?.message||err);console.error(err);$('loading').hidden=vessels.length>0;if(vessels.length>0){$('statusText').textContent='部分血管載入中斷，已保留可見的構造；重新整理可重試。';notify('血管載入未完成，部分模型仍可觀察');}loadTitle.textContent='模型暫時無法顯示';loadDetail.textContent=`${err?.message || '未知錯誤'}。請先開啟右上角「環境檢測」，再確認模型解碼與連線狀態。`; loadFill.style.width='0%';$('retry').hidden=false;}
function updateOrganLabels(){
 const root=$('organLabels');if(!root||!camera||!controls||!organShells)return;
 const pulmonary=!!stagedFlow?.some(s=>s.teachingSystem==='lung-exchange');
 // Labels are contextual, not floating captions on every whole-body view.
 const show=organShells.visible&&(pulmonary||controls.getDistance()<1.70);
 root.hidden=!show;if(!show)return;
 const width=viewEl.clientWidth,height=viewEl.clientHeight;
 const anchors={right:[-.105,1.347,.046],heart:[.034,1.288,.120],left:[.107,1.349,.045]};
 const candidates=Object.entries(anchors).map(([id,pt])=>{
  const v=new THREE.Vector3(...pt).project(camera);
  return {id,x:(v.x*.5+.5)*width,y:(-v.y*.5+.5)*height,z:v.z,cueVisible:!lessonCue.hidden};
 });
 const focus=organShells.userData.organFocus||'none';
 const visible=positionVisibleLabels(candidates,{width,height,focus});
 const byId=new Map(visible.map(p=>[p.id,p]));
 for(const el of root.children){
  const pos=byId.get(el.dataset.organ);
  el.hidden=!pos;
  if(pos){el.style.left=`${pos.x}px`;el.style.top=`${pos.y}px`;el.classList.toggle('isActive',pos.focused);}
 }
}
function focusOrgansAtTeachingStage(stage){
 if(!organShells||!organAuto||!stagedFlow)return;
 const title=stage?.title||'';
 const focus=stage?.teachingSystem==='right-heart'||stage?.teachingSystem==='left-heart'||title.includes('肺動脈幹')||title.includes('升主動脈')
  ?'heart':stage?.teachingSystem==='lung-exchange'||title.includes('右肺動脈')||title.includes('右上肺靜脈')
  ?'right-lung':'none';
 if(organShells.userData.organFocus!==focus)setOrganShellFocus(organShells,focus);
}
function invalidate(){if(pending||!renderer)return;pending=true;requestAnimationFrame(()=>{pending=false;if(renderer&&scene&&camera){updateOrganLabels();renderer.render(scene,camera);}});} 
function resize(){
 if(!renderer)return;
 const r=viewEl.getBoundingClientRect();if(r.width<10||r.height<10)return;
 renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.updateProjectionMatrix();
 // On iPad rotation, preserve the current camera angle and the teacher's pan.
 // Fit in camera-space (not world X/Y), for BOTH ten-stage and verified-route demos.
 if(activeFitCorners?.length&&controls){
  const offset=camera.position.clone().sub(controls.target);
  const min=fitDistanceForView(activeFitCorners,{
   target:controls.target.toArray(),direction:offset.toArray(),
   aspect:camera.aspect,fovDegrees:camera.fov,minimum:stagedFlow?1.06:1.18
  });
  if(stagedFlow)lessonCameraFitDistance=min;
  if(offset.length()<min){
   camera.position.copy(controls.target).add(offset.normalize().multiplyScalar(min));controls.update();
  }
 }
 enforceCameraLimits();scaleFlowMarker();invalidate();
}
function frame(){if(!camera||!controls)return;const a=window.matchMedia('(orientation: portrait)').matches;const r=viewEl.getBoundingClientRect();const fov=THREE.MathUtils.degToRad(camera.fov);const aspect=Math.max(.4,r.width/Math.max(1,r.height));const distByHeight=(modelHeight*1.19/2)/Math.tan(fov/2);const distByWidth=(.95/2)/Math.tan(fov/2)/aspect;const distance=Math.max(2.55,distByHeight,distByWidth);camera.position.set(boundsMid.x,boundsMid.y,distance+boundsMid.z);controls.target.copy(boundsMid);controls.update();invalidate();}
function initialize(){
 scene=new THREE.Scene();scene.background=null;
 camera=new THREE.PerspectiveCamera(36,1,.01,100);camera.position.set(0,.86,3.2);
 scene.add(new THREE.HemisphereLight(0xffffff,0xa5bbce,2.05));
 const light=new THREE.DirectionalLight(0xffffff,2.25);light.position.set(2.3,3.2,4);scene.add(light);
 const light2=new THREE.DirectionalLight(0x9ac8e6,.7);light2.position.set(-1,1,-3);scene.add(light2);
 renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});
 renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.35));
 renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.toneMapping=THREE.ACESFilmicToneMapping;
 renderer.toneMappingExposure=1.27;
 renderer.domElement.setAttribute('aria-label','3D 立體血管，單指旋轉，雙指平移和縮放');
 renderer.domElement.style.touchAction='none';viewEl.append(renderer.domElement);renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();errorStage(new Error('裝置暫時失去 WebGL 圖形環境，請重新載入'));});renderer.domElement.addEventListener('webglcontextrestored',()=>invalidate());
 controls=new OrbitControls(camera,renderer.domElement);controls.target.copy(boundsMid);controls.enableDamping=true;controls.dampingFactor=.105;controls.minDistance=1.88;controls.maxDistance=11;controls.panSpeed=.75;controls.zoomSpeed=.85;controls.enablePan=true;controls.screenSpacePanning=true;controls.touches={ONE:THREE.TOUCH.ROTATE,TWO:THREE.TOUCH.DOLLY_PAN};
 // On iPad, a second gesture may start before damping from the first ends.
 // Cancel the earlier settle timer instead of stopping its render loop mid-drag.
 let animating=false,settleTimer=0;
 function loop(){if(!animating)return;controls.update();updateOrganLabels();renderer.render(scene,camera);requestAnimationFrame(loop);}
 controls.addEventListener('start',()=>{clearTimeout(settleTimer);settleTimer=0;if(!animating){animating=true;requestAnimationFrame(loop);}});
 controls.addEventListener('end',()=>{clearTimeout(settleTimer);settleTimer=setTimeout(()=>{animating=false;invalidate();},500);});
 controls.addEventListener('change',()=>{enforceCameraLimits();scaleFlowMarker();invalidate();});
 scene.add(vesselGroup);
 bodyContext=buildBodyContext();scene.add(bodyContext);
 organShells=buildOrganShells();scene.add(organShells);showOrganMode(organPreferred);
 // The particle is deliberately enlarged for classroom visibility. Its position
 // comes exclusively from validated, real-GLB lumen centerlines (no fake joins).
 flowMarker=new THREE.Mesh(new THREE.SphereGeometry(.012,14,12),new THREE.MeshBasicMaterial({color:0xffd451,depthTest:false,depthWrite:false}));
 // A soft halo keeps the teaching particle visible on an iPad/projected display.
 // Both the particle and halo are intentionally NOT drawn at realistic blood-cell scale.
 const dotGlow=document.createElement('canvas');dotGlow.width=dotGlow.height=128;
 const gx=dotGlow.getContext('2d');const grad=gx.createRadialGradient(64,64,8,64,64,64);
 grad.addColorStop(0,'rgba(255,255,230,0.95)');grad.addColorStop(.24,'rgba(255,240,91,0.68)');
 grad.addColorStop(.49,'rgba(255,222,75,0.28)');grad.addColorStop(1,'rgba(255,222,75,0)');
 gx.fillStyle=grad;gx.fillRect(0,0,128,128);
 const halo=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(dotGlow),transparent:true,depthTest:false,depthWrite:false,blending:THREE.AdditiveBlending}));
 halo.scale.set(.083,.083,1);halo.renderOrder=998;flowMarker.add(halo);
 const centerDot=new THREE.Mesh(new THREE.SphereGeometry(.0055,12,8),new THREE.MeshBasicMaterial({color:0xffffff,depthTest:false,depthWrite:false}));
 centerDot.renderOrder=1001;flowMarker.add(centerDot);
 flowMarker.visible=false;flowMarker.renderOrder=999;scene.add(flowMarker);
 new ResizeObserver(resize).observe(viewEl);window.addEventListener('orientationchange',()=>setTimeout(resize,120));
 resize();frame();
 const ray=new THREE.Raycaster(),ndc=new THREE.Vector2();
 const taps=createTapGate({maxDurationMs:420,maxMovePx:10});
 const eventPoint=e=>({id:e.pointerId,x:e.clientX,y:e.clientY,t:performance.now()});
 renderer.domElement.addEventListener('pointerdown',e=>taps.down(eventPoint(e)),{passive:true});
 renderer.domElement.addEventListener('pointermove',e=>taps.move(eventPoint(e)),{passive:true});
 renderer.domElement.addEventListener('pointercancel',e=>taps.cancel(e.pointerId),{passive:true});
 renderer.domElement.addEventListener('lostpointercapture',e=>taps.cancel(e.pointerId),{passive:true});
 window.addEventListener('blur',()=>taps.reset());
 renderer.domElement.addEventListener('pointerup',e=>{
  if(!taps.up(eventPoint(e))||e.pointerType==='mouse'&&e.button!==0)return;
  const rect=renderer.domElement.getBoundingClientRect();ndc.set((e.clientX-rect.left)/rect.width*2-1,-((e.clientY-rect.top)/rect.height*2-1));ray.setFromCamera(ndc,camera);
  const hits=ray.intersectObjects(vessels.filter(v=>v.visible),false);if(hits.length)focusMesh(hits[0].object,false);else selectMesh(null);
 },{passive:true});
}
function typeColor(cat, kind){return cat==='Pulmonary artery'?0x366cbb:cat==='Pulmonary vein'?0xd44b60:kind==='arteries'?0xdb5359:0x327abc;}
function putMesh(item,kind){
 item.traverse(ob=>{if(!ob.isMesh)return;
  const nm=ob.userData.zname||ob.name.replace(/\.\d+$/,'');
  const info=levelMap[kind].get(nm); // O(1) by name, preserving 643 independent meshes.
  const cat=ob.userData.zmat||info?.type||'';
  const color=typeColor(cat,kind);
  const mat=new THREE.MeshLambertMaterial({color,side:THREE.DoubleSide});
  ob.material?.dispose?.();ob.material=mat;ob.userData.info=info||{name:nm,group:'',type:cat,level:0};ob.userData.kind=kind;ob.userData.baseColor=color;ob.userData.educationalForeground=false;
  vessels.push(ob);byType[kind].push(ob);if(!byName.has(nm))byName.set(nm,[]);byName.get(nm).push(ob);
 });
 vesselGroup.add(item);
}
function applyFilters(){
 let visible=0;
 for(const ob of vessels){const typeOk=filterType==='all'||ob.userData.kind===filterType;ob.visible=typeOk && (ob.userData.info.displayLevel??ob.userData.info.level??0)>=level && !(teachingTube && teachingTube.userData.replacedMesh===ob.userData.info.name);if(ob.visible)visible++;}
 // Temporary spotlight can show selected item even when excluded by a global filter.
 if(selected&&!selected.visible)selectMesh(null);
 layerBtn.querySelector('small').textContent=`${levelsText[level]} · ${visible} 個構造`;
 sizeLabel.textContent=`${visible} / ${vessels.length} 段可見`;
 $('statusText').textContent=window.__viewerBootState==='loaded'?(level===0?'完整解剖：已載入所有血管':level===1?'主要血管：已隱藏胸壁細分支':'核心主幹：保留重點血管'):`模型分批載入中：${vessels.length} / 643 段`;
 invalidate();
}
function selectMesh(ob){
 if(selected){selected.material.color.setHex(selected.userData.baseColor);selected.material.emissive?.setHex(0x000000);}
 selected=ob;
 if(ob){ob.material.color.setHex(0xffc44d);ob.material.emissive?.setHex(0x463000);
   const i=ob.userData.info;screenMsg.hidden=false;screenMsg.textContent=regionOfVessel(i.name);
 }else screenMsg.hidden=true;
 invalidate();
}
function focusMesh(ob,moveCamera=true){if(!ob)return; if(!ob.visible){level=0;filterType='all';updateFilterButtons();applyFilters();}
 selectMesh(ob);
 if(moveCamera){const box=new THREE.Box3().setFromObject(ob);const center=box.getCenter(new THREE.Vector3());const radius=box.getSize(new THREE.Vector3()).length();
  const offset=camera.position.clone().sub(controls.target);controls.target.copy(center);camera.position.copy(center.add(offset.normalize().multiplyScalar(Math.max(1.18,Math.min(2.8,radius*5)))));controls.update();}
}
// V0.30: render-only animation on validated single-lumen vessel centerlines.
// These are NOT a full virtual circulation path: exchanges and unmodelled tissue are excluded.
function flowPosition(frac){
 if(!flowCurve?.length)return null;
 const s=Math.max(0,Math.min(1,frac))*flowTotal;
 let lo=0,hi=flowSegments.length-1;
 while(lo<hi){const m=(lo+hi)>>1;if(flowSegments[m]<s)lo=m+1;else hi=m;}
 const i=Math.max(0,Math.min(flowCurve.length-2,lo-1));
 const start=flowSegments[i],end=flowSegments[i+1];
 const k=end>start?(s-start)/(end-start):0;
 return flowCurve[i].clone().lerp(flowCurve[i+1],k);
}
function stopFlow(clear=true){
 flowPlaying=false;if(flowFrame)cancelAnimationFrame(flowFrame);flowFrame=0;flowLast=0;
 if(clear){
  restoreOrganMode();
  if(organShells)setOrganShellFocus(organShells,'none');
  flowSlug=null;flowCurve=null;flowMarker.visible=false;flowTime=0;flowTotal=0;stagedFlow=null;stagedTimeline=null;stagedAt=0;stagedMs=0;activeLessonNote='';
  removeStageGuide();spotlightAt=-1;cueAt=-1;routeUiAt=-1;restoreVesselColors();
  if(lessonCue)lessonCue.hidden=true;
  if(flowMarker)flowMarker.scale.setScalar(1);
  lessonCameraFitDistance=0;activeFitCorners=null;
  if(teachingTube){scene.remove(teachingTube);teachingTube.traverse(o=>{if(o.isMesh){o.geometry.dispose();o.material.dispose();}});teachingTube=null;applyFilters();}
  if(teachingSchematic){scene.remove(teachingSchematic);teachingSchematic.traverse(o=>{if(o.isMesh){o.geometry.dispose();o.material.dispose();}});teachingSchematic=null;}
  if(!restoreExploreViewAfterDemo()&&controls){controls.minDistance=1.88;enforceCameraLimits();}
 }
 if($('toggleFlow'))$('toggleFlow').textContent='▶ 繼續';
 invalidate();
}
function moveFlow(){
 const p=flowPosition(flowTime);if(p&&flowMarker){flowMarker.position.copy(p);flowMarker.visible=true;scaleFlowMarker();}
 invalidate();
}
// V0.32: The anatomical model is preserved; in the teacher-led lesson only,
// one complicated pulmonary artery fork is represented by a deliberately
// simplified tube. Original heart chambers and lung capillaries remain CONCEPT
// stages and the software never claims their geometry is anatomically exact.
function buildTeachingTubes(stages){
 const group=new THREE.Group();
 // These colored pipes exist only during their corresponding teacher-led lesson.
 for(const stage of stages.filter(s=>s.kind==='simplified')){
  const parts=new THREE.Group();parts.userData.stageTitle=stage.title;
  for(const [i,seg] of stage.segments.entries()){
   const pts=seg.points.map(p=>new THREE.Vector3(...p));
   const curve=new THREE.CatmullRomCurve3(pts,false,'centripetal');
   const isArterial=stage.oxygen==='high';
   const color=isArterial?0xe56864:(i===2?0x79b5e6:0x31b2e4);
   const tube=new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(16,pts.length),stage.radiusModelUnit||.0032,10,false),
       new THREE.MeshBasicMaterial({color,transparent:true,opacity:.93,depthTest:false,depthWrite:false}));
   tube.name=seg.title+'（教學簡化，不代表精確解剖）';tube.userData.educationalApproximation=true;tube.renderOrder=998;parts.add(tube);
  }
  group.add(parts);
 }
 group.userData.replacedMesh=stages.some(x=>x.title.includes('肺動脈分叉'))?'Bifurcation of pulmonary trunk':null;
 scene.add(group);return group;
}

// V0.33: Three clearly marked pedagogic bridges. The tube/heart/alveolus
// geometry is NOT source anatomy. The bridge endpoints match the original GLB
// centerlines exactly, preventing the flow dot teleporting between stages.
function buildTeachingSchematics(stages){
 const group=new THREE.Group();
 const low=0x36aee4,high=0xe56864;
 for(const stage of stages.filter(s=>s.kind==='schematic')){
  const shape=new THREE.Group();shape.userData.teachingSystem=stage.teachingSystem;
  const add=mesh=>{mesh.userData.educationalApproximation=true;shape.add(mesh);return mesh;};
  const pts=stage.points.map(p=>new THREE.Vector3(...p));
  const curve=new THREE.CatmullRomCurve3(pts,false,'centripetal');
  if(stage.teachingSystem==='lung-exchange'){
   // Two colored halves represent oxygen being gained at the alveolus.
   for(let half=0;half<2;half++){
    const path=curve.getSpacedPoints(64).slice(half*32,half*32+33);
    const halfCurve=new THREE.CatmullRomCurve3(path,false,'centripetal');
    const tube=add(new THREE.Mesh(new THREE.TubeGeometry(halfCurve,44,stage.radiusModelUnit,10,false),new THREE.MeshLambertMaterial({color:half?high:low,transparent:true,opacity:.92,depthTest:false,depthWrite:false})));
    tube.renderOrder=997;
   }
   const sphere=add(new THREE.Mesh(new THREE.SphereGeometry(stage.alveolus.radius,20,14),new THREE.MeshLambertMaterial({color:0xf9f5e4,transparent:true,opacity:.65,depthTest:false,depthWrite:false})));
   sphere.position.set(...stage.alveolus.center);sphere.renderOrder=996;
   sphere.name='肺泡概念示意：氧氣進入血液、二氧化碳離開血液';
  }else if(stage.teachingSystem==='arm-exchange'){
   // Arterial blood releases O₂ to local tissue and takes up CO₂:
   // red -> blue. The actual microscopic capillary bed is not present in the GLB.
   const path=curve.getSpacedPoints(64);
   for(let half=0;half<2;half++){
    const halfCurve=new THREE.CatmullRomCurve3(path.slice(half*32,half*32+33),false,'centripetal');
    const mesh=add(new THREE.Mesh(new THREE.TubeGeometry(halfCurve,44,stage.radiusModelUnit,10,false),
      new THREE.MeshLambertMaterial({color:half?low:high,transparent:true,opacity:.92,depthTest:false,depthWrite:false})));
    mesh.renderOrder=997;
   }
   const tissue=add(new THREE.Mesh(new THREE.SphereGeometry(stage.tissue.radius,20,14),
     new THREE.MeshLambertMaterial({color:0xf8dfad,transparent:true,opacity:.32,depthTest:false,depthWrite:false})));
   tissue.position.set(...stage.tissue.center);tissue.renderOrder=996;
   tissue.name='前臂組織交換示意：氧氣交給細胞，二氧化碳進入血液';
  }else if(stage.teachingSystem==='right-atrium'){
   const tube=add(new THREE.Mesh(new THREE.TubeGeometry(curve,36,stage.radiusModelUnit,10,false),
     new THREE.MeshLambertMaterial({color:low,transparent:true,opacity:.82,depthTest:false,depthWrite:false})));
   tube.renderOrder=997;
   for(const chamber of stage.chambers){
    const bubble=add(new THREE.Mesh(new THREE.SphereGeometry(1,24,18),
      new THREE.MeshLambertMaterial({color:0x64b4ec,transparent:true,opacity:.52,depthTest:false,depthWrite:false})));
    bubble.scale.set(...chamber.radius);bubble.position.set(...chamber.center);bubble.name=chamber.name+'（教學示意）';
   }
  }else{
   const blue=stage.teachingSystem==='right-heart';
   const tube=add(new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(48,pts.length),stage.radiusModelUnit,10,false),new THREE.MeshLambertMaterial({color:blue?low:high,transparent:true,opacity:.78,depthTest:false,depthWrite:false})));
   tube.renderOrder=997;
   for(const chamber of stage.chambers){
    const bubble=add(new THREE.Mesh(new THREE.SphereGeometry(1,24,18),new THREE.MeshLambertMaterial({color:blue?0x64b4ec:0xed8585,transparent:true,opacity:.57,depthTest:false,depthWrite:false})));
    bubble.scale.set(...chamber.radius);bubble.position.set(...chamber.center);bubble.renderOrder=996;
    bubble.name=chamber.name+'（教學示意）';
   }
  }
  shape.visible=false;group.add(shape);
 }
 scene.add(group);return group;
}
// V0.36: a temporary path guide and low-cost color spotlight help a whole class
// follow one stage without altering the original anatomical GLBs.
function removeStageGuide(){
 if(!stageGuide)return;
 scene.remove(stageGuide);stageGuide.geometry.dispose();stageGuide.material.dispose();stageGuide=null;
}
function setVesselLessonDrawOrder(ob,foreground){
 const wanted=teachingVesselStyle(foreground);
 if(ob.userData.educationalForeground===foreground)return;
 ob.userData.educationalForeground=foreground;
 const mat=ob.material;
 mat.transparent=wanted.transparent;
 mat.opacity=wanted.opacity;
 mat.depthTest=wanted.depthTest;
 mat.depthWrite=wanted.depthWrite;
 ob.renderOrder=wanted.renderOrder;
 mat.needsUpdate=true;
}
function restoreVesselColors(){
 for(const ob of vessels){
  setVesselLessonDrawOrder(ob,false);
  if(ob===selected)continue;
  ob.material.color.setHex(ob.userData.baseColor);ob.material.emissive?.setHex(0x000000);
 }
 invalidate();
}
// V0.38: Keep the *before and after* major vessels recognizable during an
// exchange/schematic stop. A concept stage is not an unlabelled blank background.
function lessonMeshNames(stage){
 return stage?.kind==='real'?(stage.meshes||(stage.mesh?[stage.mesh]:[])):[];
}
function nearestRealNames(start,dir){
 if(!stagedFlow)return [];
 for(let i=start+dir;i>=0&&i<stagedFlow.length;i+=dir){
  const names=lessonMeshNames(stagedFlow[i]);
  if(names.length)return names;
 }
 return [];
}
function highlightTeachingStage(stage){
 if(spotlightAt===stagedAt)return;
 spotlightAt=stagedAt;
 removeStageGuide();
 const active=new Set(lessonMeshNames(stage));
 // At a bridge/exchange, maintain recognizable vessels on BOTH sides.
 const context=new Set(stage.kind==='real'?[]:[
  ...nearestRealNames(stagedAt,-1),...nearestRealNames(stagedAt,1)
 ]);
 const soft=new THREE.Color(0x9fb2be);
 const pulmonary=stagedFlow?.some(s=>s.teachingSystem==='lung-exchange')||false;
 for(const ob of vessels){
  const name=ob.userData.info.name;
  const isActive=active.has(name),isContext=context.has(name);
  setVesselLessonDrawOrder(ob,teachingForeground({
   organMode:organShells?.userData.organMode,pulmonary,selected:ob===selected,
   active:isActive,context:isContext
  }));
  if(ob===selected)continue;
  ob.material.color.setHex(ob.userData.baseColor);
  if(!isActive)ob.material.color.lerp(soft,isContext ? .16 : .66);
  // Elevate only the vessel(s) related to this stage. An educational view
  // through a translucent shell must never alter the real GLB mesh.
  ob.material.emissive?.setHex(isActive?0x16140a:0);
 }
 // For a genuine GLB centreline, show a small guidance trace. On a conceptual
 // bridge, its own deliberately schematic tube already explains the gap.
 if(stage.kind==='real'&&stage.points?.length>1){
  const pts=stage.points.map(p=>new THREE.Vector3(...p));
  const curve=new THREE.CatmullRomCurve3(pts,false,'centripetal');
  stageGuide=new THREE.Mesh(
    new THREE.TubeGeometry(curve,Math.max(32,pts.length),.0038,8,false),
    new THREE.MeshBasicMaterial({color:0xffcc52,transparent:true,opacity:.96,depthTest:false,depthWrite:false})
  );
  stageGuide.userData.educationalGuide=true;
  stageGuide.renderOrder=997;scene.add(stageGuide);
 }
 invalidate();
}
function updateLessonCue(stage){
 if(!lessonCue||!stage||cueAt===stagedAt)return;
 cueAt=stagedAt;
 const title=stage.teachingSystem==='lung-exchange'?'肺臟':stage.teachingSystem==='arm-exchange'?'手臂':(stage.teachingSystem==='right-heart'||stage.teachingSystem==='left-heart'||stage.teachingSystem==='right-atrium')?'心臟':regionForNode(stage.title);
 const change=stage.oxygen==='transition'?'氧氣進入血液 ↑':stage.oxygen==='high-to-low'?'氧氣交給組織 ↓':stage.oxygen==='high'?'血氧較多':'血氧較少';
 lessonCueName.textContent=title;
 lessonCueOxygen.textContent=change;
 lessonCue.hidden=false;
}
function scaleFlowMarker(){
 if(!flowMarker||!flowMarker.visible||!camera)return;
 const depth=Math.max(.15,camera.position.distanceTo(flowMarker.position));
 const pixelsPerUnit=viewEl.clientHeight/(2*Math.tan(THREE.MathUtils.degToRad(camera.fov)/2)*depth);
 // ~12 px bright core at full-body scale; a soft glow adds visibility without hiding anatomy.
 const wanted=12/Math.max(1,pixelsPerUnit)/.012;
 flowMarker.scale.setScalar(THREE.MathUtils.clamp(wanted,1,5.0));
}

function showTeachingStage(stage){
 if(!teachingSchematic)return;
 for(const child of teachingSchematic.children)child.visible=stage?.kind==='schematic'&&child.userData.teachingSystem===stage.teachingSystem;
 if(teachingTube)for(const child of teachingTube.children)child.visible=stage?.kind==='simplified'&&child.userData.stageTitle===stage.title;
}
function stageRender(){
 if(!stagedFlow)return;
 const stage=stagedFlow[stagedAt];if(!stage)return;
 const hasGeometry=stage.kind==='real'||stage.kind==='simplified'||stage.kind==='schematic';
 showTeachingStage(stage);
 focusOrgansAtTeachingStage(stage);
 highlightTeachingStage(stage);
 updateLessonCue(stage);
 flowMarker.visible=hasGeometry;
 const oxygenProgress=Math.min(1,Math.max(0,stagedMs/stage.durationMs));
 flowMarker.material.color.setHex(stage.oxygen==='transition'?new THREE.Color(0x7dd3fc).lerp(new THREE.Color(0xffba62),oxygenProgress).getHex():stage.oxygen==='high-to-low'?new THREE.Color(0xffba62).lerp(new THREE.Color(0x7dd3fc),oxygenProgress).getHex():stage.oxygen==='high'?0xffba62:0x7dd3fc);
 if(hasGeometry){
  // Arc lengths are prepared only once per lesson, not recomputed on every frame.
  flowMarker.position.set(...positionOnStage(stagedTimeline[stagedAt],stagedMs));
  scaleFlowMarker();
 }
 if(routeUiAt!==stagedAt){
  routeUiAt=stagedAt;
  $('routeIndex').textContent=`${stagedAt+1}/${stagedFlow.length} 站`;
  $('routeResult').hidden=false;$('routeResult').textContent=regionForNode(stage.title);
 }
 invalidate();
}
function teachingFit(stages,aspect){
 // All real centreline points and explicit educational bridge points remain in
 // the bounds. The pulmonary lesson also includes the actual organ envelopes.
 const points=stages.flatMap(s=>(s.points||[]).map(p=>new THREE.Vector3(...p)));
 if(!points.length)return {center:boundsMid.clone(),distance:1,corners:[]};
 const bounds=new THREE.Box3().setFromPoints(points);
 if(organShells&&stages.some(s=>s.teachingSystem==='lung-exchange'))
  bounds.union(new THREE.Box3().setFromObject(organShells));
 const corners=cornersFromBounds(bounds.min.toArray(),bounds.max.toArray());
 const center=new THREE.Vector3(...centerOfBounds(corners));
 const distance=fitDistanceForView(corners,{
  target:center.toArray(),direction:[0,0,1],fovDegrees:camera.fov,
  aspect:Math.max(.38,aspect||1),padding:1.34,minimum:1.06
 });
 return {center,distance,corners};
}
function startTeachingLesson(lesson,focus,note=''){ 
 if(!lesson?.stages?.length){notify('教學路徑資料尚未載入');return;}
 if(vessels.length<68){notify('核心血管尚未載入完成');return;}
 for(const stage of lesson.stages){
  if(stage.kind!=='real')continue;
  for(const name of stage.meshes || (stage.mesh?[stage.mesh]:[])){
   if(!byName.has(name)){notify(`正在載入血管：${name}`);return;}
  }
 }
 stopFlow(true);selectMesh(null);saveExploreViewBeforeDemo();
 stagedFlow=lesson.stages;stagedTimeline=prepareTeachingTimeline(stagedFlow);stagedAt=0;stagedMs=0;spotlightAt=-1;cueAt=-1;routeUiAt=-1;activeLessonNote=note;
 if(stagedFlow.some(s=>s.teachingSystem==='lung-exchange'))showOrgansForPulmonaryLesson();
 teachingTube=buildTeachingTubes(stagedFlow);
 teachingSchematic=buildTeachingSchematics(stagedFlow);
 // The teacher may restore the complete model with the main filter control.
 level=2;filterType='all';updateFilterButtons();applyFilters();
 // V0.48: playback always uses a stable head-to-toe view, not a close-up.
 // The full circulation remains visible throughout the lesson.
 activeFitCorners=null;lessonCameraFitDistance=0;
 controls.minDistance=1.06;frame();
 $('prev').hidden=false;$('next').hidden=false;$('toggleFlow').hidden=false;$('player').hidden=false;
 $('toggleFlow').textContent='⏸ 暫停';$('statusText').textContent=focus.title;
 stageRender();flowPlaying=true;flowLast=0;flowFrame=requestAnimationFrame(flowStep);
}
function startCardiopulmonary(){
 startTeachingLesson(cardiopulmonary,{center:[0,1.334,.016],width:.50,title:'心肺教學：真實血管＋明示簡化的四心腔與微血管'});
}
function startSystemicArm(){
 startTeachingLesson(systemicArm,{center:[.10,1.17,.014],width:1.05,title:'體循環教學：主動脈 → 左手臂組織 → 上腔靜脈 → 右心房'});
}
function stageTick(now){
 if(!flowLast)flowLast=now;
 // 80 ms cap avoids jumping ahead after a tab is suspended. Within that frame,
 // fractional time is carried to the next stage with no lost remainder.
 const delta=Math.max(0,Math.min(80,now-flowLast));flowLast=now;
 const next=advanceTeachingTimeline(stagedTimeline,stagedAt,stagedMs,delta);
 stagedAt=next.index;stagedMs=next.ms;
 stageRender();
 if(next.ended){flowPlaying=false;flowFrame=0;$('toggleFlow').textContent='↻ 重播';return;}
 flowFrame=requestAnimationFrame(flowStep);
}
function flowStep(now){
 if(!flowPlaying)return;
 if(stagedFlow){stageTick(now);return;}

 if(!flowLast)flowLast=now;
 flowTime=Math.min(1,flowTime+(now-flowLast)/7600);flowLast=now;
 moveFlow();
 $('routeIndex').textContent=`光點 ${Math.round(flowTime*100)}%`;
 if(flowTime>=1){flowPlaying=false;flowFrame=0;$('toggleFlow').textContent='↻ 重播';return;}
 flowFrame=requestAnimationFrame(flowStep);
}
function toggleFlow(){
 if(stagedFlow){
  if(flowPlaying){stopFlow(false);$('toggleFlow').textContent='▶ 繼續';return;}
  if(stagedAt===stagedFlow.length-1&&stagedMs>=stagedFlow[stagedAt].durationMs){stagedAt=0;stagedMs=0;stageRender();}
  flowPlaying=true;flowLast=0;$('toggleFlow').textContent='⏸ 暫停';flowFrame=requestAnimationFrame(flowStep);return;
 }
 if(!flowSlug)return;
 if(flowPlaying){stopFlow(false);$('toggleFlow').textContent='▶ 繼續';return;}
 if(flowTime>=1)flowTime=0;
 flowPlaying=true;flowLast=0;$('toggleFlow').textContent='⏸ 暫停';
 flowFrame=requestAnimationFrame(flowStep);
}
function startVerifiedRoute(slug){
 const item=verifiedPaths?.routes?.[slug];
 if(!item){notify('已驗證路徑資料尚未載入');return;}
 if(!vessels.length){notify('請先完成血管模型載入');return;}
 stopFlow(true);saveExploreViewBeforeDemo();flowSlug=slug;flowCurve=item.points.map(v=>new THREE.Vector3(...v));
 flowSegments=[0];for(let i=1;i<flowCurve.length;i++)flowSegments.push(flowSegments[i-1]+flowCurve[i].distanceTo(flowCurve[i-1]));
 flowTotal=flowSegments[flowSegments.length-1];flowTime=0;
 if(flowTotal<.01){notify('中心線距離資料異常');stopFlow(true);return;}
 // V0.48: show the route in the full body, never auto-zoom into a vessel.
 activeFitCorners=null;lessonCameraFitDistance=0;frame();
 const verifiedSegments=item.segments.length;
 $('routeResult').hidden=false;$('routeResult').textContent=labelForVerifiedRoute(slug);
 $('prev').hidden=true;$('next').hidden=true;$('toggleFlow').hidden=false;
 $('player').hidden=false;$('routeIndex').textContent='光點 0%';
 moveFlow();toggleFlow();
}
function showRouteAt(){stopFlow(true);$('prev').hidden=false;$('next').hidden=false;$('toggleFlow').hidden=true;if(!currentRoute?.length)return;
 const step=currentRoute[routeAt];const hit=routeMapping[step]||null;const meshes=hit?byName.get(hit):null;
 if(meshes?.length){focusMesh(meshes[0],false);$('routeResult').hidden=false;$('routeResult').textContent=`${displayName(step)}　${routeAt+1}/${currentRoute.length}`;
 }else{selectMesh(null);$('routeResult').textContent=`${displayName(step)}　${routeAt+1}/${currentRoute.length}`}
 const exchange=window.CirculationEngine?.atStage(currentRoute,routeAt,false);
 // The color transition is displayed on the flow marker; no paragraph is needed.
 $('routeIndex').textContent=`${routeAt+1} / ${currentRoute.length}`;
}
function renderRouteAssist(plan){
 suggestedPlan=plan||null;
 const box=$('routeAssist');
 if(!box)return;
 if(!plan){box.hidden=true;$('routeAssistText').textContent='';return;}
 box.hidden=false;$('routeAssistText').textContent='';
}
function playSuggestedPlan(){
 if(!suggestedPlan)return;
 if(suggestedPlan.kind==='verified'){
  startVerifiedRoute(suggestedPlan.slug);
  // Playback remains visual: no appended technical explanation.
  return;
 }
 if(suggestedPlan.kind==='lesson'&&suggestedPlan.lesson==='left-arm-systemic-return'&&systemicArm?.stages?.length){
  const focus=suggestedPlan.range[0]===0
   ? {center:[.10,1.17,.014],width:1.05,title:'體循環教學：心臟 → 左手臂組織'}
   : {center:[.18,1.14,.014],width:.85,title:'體循環教學：左手臂 → 上腔靜脈 → 右心房'};
  startTeachingLesson({stages:systemicArm.stages.slice(suggestedPlan.range[0],suggestedPlan.range[1]+1)},focus,suggestedPlan.note||'');
 }
}
const routeMapping={
 pulmonary_trunk:'Pulmonary trunk',right_pulmonary_a:'Right pulmonary artery',left_pulmonary_a:'Left pulmonary artery',
 right_pv1:'Right superior pulmonary vein',left_pv1:'Left superior pulmonary vein',
 aortic_root:'Ascending aorta',aortic_arch:'Aortic arch',thoracic_aorta:'Thoracic aorta',abdominal_aorta:'Abdominal aorta',
 brachiocephalic_a:'Brachiocephalic trunk',right_carotid:'Right common carotid artery',left_carotid:'Left common carotid artery',
 right_subclavian_a:'Right subclavian artery',left_subclavian_a:'Left subclavian artery',
 right_axillary_a:'Axillary artery.r',left_axillary_a:'Axillary artery.l',
 right_brachial_a:'Brachial artery.r',left_brachial_a:'Brachial artery.l',
 right_radial_a:'Radial artery.r',left_radial_a:'Radial artery.l',
 right_brachial_v:'Brachial veins.r',left_brachial_v:'Brachial veins.l',
 right_axillary_v:'Axillary vein.r',left_axillary_v:'Axillary vein.l',
 right_forearm_v:'Radial veins.r',left_forearm_v:'Radial veins.l',
 right_subclavian_v:'Right subclavian vein',left_subclavian_v:'Left subclavian vein',
 right_brachio_v:'Right brachiocephalic vein',left_brachio_v:'Left brachiocephalic vein',
 right_jugular_v:'Internal jugular vein.r',left_jugular_v:'Internal jugular vein.l',
 svc:'Superior vena cava',ivc:'Inferior vena cava (abdominal part)',ivc_thoracic:'Inferior vena cava (thoracic part)',
 right_iliac_a:'Common iliac artery.r',left_iliac_a:'Common iliac artery.l',
 right_external_iliac_a:'External iliac artery.r',left_external_iliac_a:'External iliac artery.l',
 right_femoral_a:'Femoral artery.r',left_femoral_a:'Femoral artery.l',
 right_tibial_a:'Anterior tibial artery.r',left_tibial_a:'Anterior tibial artery.l',
 right_popliteal_a:'Popliteal artery.r',left_popliteal_a:'Popliteal artery.l',
 right_iliac_v:'Common iliac vein.r',left_iliac_v:'Common iliac vein.l',
 right_external_iliac_v:'External iliac vein.r',left_external_iliac_v:'External iliac vein.l',
 right_popliteal_v:'Popliteal vein.r',left_popliteal_v:'Popliteal vein.l',
 right_femoral_v:'Femoral vein.r',left_femoral_v:'Femoral vein.l',
 right_tibial_v:'Anterior tibial veins.r',left_tibial_v:'Anterior tibial veins.l',
 right_renal_a:'Right renal artery',left_renal_a:'Left renal artery',
 right_renal_v:'Right renal vein',left_renal_v:'Left renal vein',
 celiac_a:'Coeliac trunk',hepatic_a:'Common hepatic artery',intestinal_a:'Superior mesenteric artery',
 mesenteric_v:'Superior mesenteric vein',portal_v:'Hepatic portal vein',hepatic_v:'Hepatic veins',
};
const REGION_CHOICES=[
 ['lv','左心室'],['ra','右心房'],['rv','右心室'],['la','左心房'],
 ['right_lung','右肺'],['left_lung','左肺'],['left_forearm_cap','左手臂'],['right_forearm_cap','右手臂'],
 ['left_leg_cap','左下肢'],['right_leg_cap','右下肢'],['right_brain_cap','腦部'],
 ['small_intestine','小腸'],['stomach','胃'],['liver','肝臟'],['right_kidney','右腎'],['left_kidney','左腎']
];
const regionLabels=new Map(REGION_CHOICES);
function regionForNode(id){
 if(regionLabels.has(id))return regionLabels.get(id);
 if(/[㐀-鿿]/.test(id)){
  if(id.includes('肺'))return '肺臟';
  if(id.includes('心')||id.includes('主動脈'))return '心臟';
  if(id.includes('手')||id.includes('臂')||id.includes('前臂'))return '手臂';
  if(id.includes('腿')||id.includes('下肢'))return '下肢';
  if(id.includes('腎'))return '腎臟';
  if(id.includes('腸'))return '小腸';
  if(id.includes('肝'))return '肝臟';
  if(id.includes('腦'))return '頭部';
 }
 if(['lv','la','ra','rv','svc','ivc','ivc_thoracic','aortic_root','aortic_arch','pulmonary_trunk'].includes(id))return '心臟';
 if(id.includes('pulmonary')||id.includes('_pv')||id.includes('lung'))return '肺臟';
 if(id.includes('brain')||id.includes('carotid')||id.includes('jugular'))return '頭部';
 if(id.includes('arm')||id.includes('axillary')||id.includes('brachial')||id.includes('radial')||id.includes('subclavian')||id.includes('forearm'))return '手臂';
 if(id.includes('leg')||id.includes('tibial')||id.includes('popliteal')||id.includes('iliac')||id.includes('femoral'))return '下肢';
 if(id.includes('renal')||id.includes('kidney'))return '腎臟';
 if(id.includes('mesenteric')||id.includes('intestinal'))return '小腸';
 if(id.includes('gastric')||id.includes('stomach'))return '胃';
 if(id.includes('hepatic')||id.includes('portal')||id.includes('liver'))return '肝臟';
 return '身體';
}
function regionOfVessel(n){return regionForNode(String(n).toLowerCase().replaceAll(' ','_'));}
const verifiedNames={
 'right-pulmonary-exchange':'心臟 ↔ 肺臟','left-arm-systemic-return':'心臟 ↔ 左手臂',
 'left-arm-artery':'心臟 → 左手臂','left-arm-vein':'左手臂 → 心臟',
 'right-arm-artery':'心臟 → 右手臂','right-arm-vein':'右手臂 → 心臟',
 'left-leg-artery-proximal':'心臟 → 左下肢','left-leg-vein':'左下肢 → 心臟'
};
function labelForVerifiedRoute(slug){return verifiedNames[slug]||'血流示範';}
const names={ra:'右心房',rv:'右心室',la:'左心房',lv:'左心室',right_lung:'右肺交換區',left_lung:'左肺交換區',stomach:'胃部交換區',small_intestine:'小腸交換區',right_kidney:'右腎交換區',left_kidney:'左腎交換區',liver:'肝臟交換區'};
function displayName(id){return regionLabels.get(id)||names[id]||regionForNode(id);}
function setupRoute(){const g=window.CirculationEngine;if(!g)return;const a=$('from'),b=$('to');
 // Start/end choices are teaching regions, not an English vessel-name list.
 for(const sel of [a,b])for(const [id,label] of REGION_CHOICES){
  const op=document.createElement('option');op.value=id;op.textContent=label;sel.append(op);
 }
 a.value='lv';b.value='left_forearm_cap';
 $('calculate').onclick=()=>{stopFlow(true);renderRouteAssist(null);const route=g.findPath(a.value,b.value);if(!route){$('routeResult').hidden=false;$('routeResult').textContent='↺ 換一組器官';$('player').hidden=true;return;}currentRoute=route;routeAt=0;activeFitCorners=null;frame();$('player').hidden=false;showRouteAt();renderRouteAssist(g.suggestVisualization?.(a.value,b.value)||null);};
 $('prev').onclick=()=>{if(stagedFlow){stagedAt=Math.max(0,stagedAt-1);stagedMs=0;flowLast=0;stageRender();return;}if(currentRoute){routeAt=Math.max(0,routeAt-1);showRouteAt();}};
 $('next').onclick=()=>{if(stagedFlow){stagedAt=Math.min(stagedFlow.length-1,stagedAt+1);stagedMs=0;flowLast=0;stageRender();return;}if(currentRoute){routeAt=Math.min(currentRoute.length-1,routeAt+1);showRouteAt();}};
 $('playDemo').onclick=()=>{renderRouteAssist(null);const selected=$('demoPick').value;if(selected==='right-pulmonary-exchange')startCardiopulmonary();else if(selected==='left-arm-systemic-return')startSystemicArm();else startVerifiedRoute(selected);};
 $('toggleFlow').onclick=toggleFlow;
 $('playSuggested').onclick=playSuggestedPlan;
}
function updateFilterButtons(){[['allVessels','all'],['arteriesOnly','arteries'],['veinsOnly','veins']].forEach(([id,k])=>$(id).classList.toggle('active',k===filterType));}
function buildSearch(){const list=$('searchList');const q=$('search').value.trim().toLowerCase();list.replaceChildren();if(q.length<2)return;
 const hits=[...byName.keys()].filter(n=>n.toLowerCase().includes(q)).slice(0,12);
 for(const n of hits){const btn=document.createElement('button');btn.textContent=n;btn.onclick=()=>{const obj=byName.get(n)[0];focusMesh(obj,true);closeTools();};list.append(btn);}
}
function closeTools(){$('tools').hidden=true;$('shade').hidden=true;$('toolBtn').setAttribute('aria-expanded','false');}
function attachControls(){
 if(organBtn)organBtn.onclick=()=>showOrganMode(nextOrganMode(organShells?.userData.organMode||organPreferred),{manual:true});
 $('toolBtn').onclick=()=>{$('tools').hidden=!$('tools').hidden;$('shade').hidden=$('tools').hidden;$('toolBtn').setAttribute('aria-expanded',String(!$('tools').hidden));};
 $('closeTools').onclick=closeTools;$('shade').onclick=closeTools;
 layerBtn.onclick=()=>{flagManualFilter();level=(level+1)%3;applyFilters();notify(`目前為「${levelsText[level]}」層級`);};
 $('routeBtn').onclick=()=>{$('routePanel').hidden=!$('routePanel').hidden;};
 $('closeRoute').onclick=()=>{$('routePanel').hidden=true;stopFlow(true);selectMesh(null);renderRouteAssist(null);};
 $('resetBtn').onclick=()=>{stopFlow(true);frame();selectMesh(null);renderRouteAssist(null);notify('已回到全身視角');};
 for(const [id,value] of [['allVessels','all'],['arteriesOnly','arteries'],['veinsOnly','veins']])$(id).onclick=()=>{flagManualFilter();filterType=value;updateFilterButtons();applyFilters();};
 $('search').addEventListener('input',buildSearch);
 for(const b of document.querySelectorAll('[data-view]'))b.onclick=()=>{const d=controls.getDistance();const t=controls.target;
  const x={front:[0,0,1],back:[0,0,-1],left:[-1,0,0],right:[1,0,0]}[b.dataset.view];camera.position.copy(t).add(new THREE.Vector3(...x).multiplyScalar(d));controls.update();closeTools();};

 window.addEventListener('keydown',e=>{if(e.key==='Escape')closeTools();});
 setupRoute();
}
async function start(){try{
 initialize();attachControls();
 const resp=await fetch('./models/mesh-levels.json');if(!resp.ok)throw Error('找不到血管對照資料');levels=await resp.json();for(const key of ['arteries','veins'])levelMap[key]=new Map((levels[key]||[]).map(x=>[x.name,x]));
 // Staged lesson: mixed authentic vessel centerlines and clearly indicated model gaps.
 try{const cp=await fetch('./models/cardiopulmonary-stages.json');if(cp.ok){cardiopulmonary=await cp.json();if(cardiopulmonary.stages.length!==10||cardiopulmonary.stages.filter(s=>s.kind==='schematic').length!==3)throw Error('心肺示意資料不符合十站規格');}}
 catch(err){console.warn('Cardiopulmonary lesson unavailable',err);cardiopulmonary=null;}
 // The body-systemic loop uses verified arterial/venous centrelines, with capillary and minor junction approximations explicitly labelled.
 try{const sys=await fetch('./models/systemic-left-arm-stages.json');if(sys.ok){systemicArm=await sys.json();if(systemicArm.stages.length!==10)throw Error('體循環示範資料數量不符');}}
 catch(err){console.warn('Systemic arm lesson unavailable',err);systemicArm=null;}
 // Precomputed only from real decoded GLB surfaces. Missing file disables demos, not anatomy.
 try{const vr=await fetch('./models/verified-paths.json');if(vr.ok){verifiedPaths=await vr.json();if(Object.keys(verifiedPaths.routes||{}).length!==6)throw Error('中心線路徑數量不符');}}
 catch(error){console.warn('Validated animation paths unavailable; step-based exploration still works:',error);verifiedPaths=null;}
 const draco=new DRACOLoader();draco.setDecoderPath(window.__vendorLocal ? './vendor/three/examples/jsm/libs/draco/' : window.__threeCdn+'examples/jsm/libs/draco/');draco.setWorkerLimit(1);
 const loader=new GLTFLoader();loader.setDRACOLoader(draco);
 // Six disjoint original-Draco mesh sets: show core after just 177 KB,
 // then add main branches, then fine vessels. No vessel is transferred twice.
 const files=[
  ['arteries-core-only','arteries','核心動脈'],['veins-core-only','veins','核心靜脈'],
  ['arteries-main-extra','arteries','主要動脈分支'],['veins-main-extra','veins','主要靜脈分支'],
  ['arteries-fine-extra','arteries','完整動脈細分支'],['veins-fine-extra','veins','完整靜脈細分支']
 ];
 for(let idx=0;idx<files.length;idx++){
  const [file,key,label]=files[idx];
  loadTitle.textContent=`載入${label}…`;
  loadDetail.textContent=`分批解碼中（${idx+1} / ${files.length}），已載入 ${vessels.length} 段`;
  loadFill.style.width=`${idx/files.length*100}%`;
  const item=await loader.loadAsync(`./models/${file}.glb`,ev=>{
    if(ev.total){const pct=(idx+ev.loaded/ev.total)/files.length*100;loadFill.style.width=`${Math.min(98,pct)}%`;}
  });
  putMesh(item.scene,key);
  if(stagedFlow){spotlightAt=-1;highlightTeachingStage(stagedFlow[stagedAt]);}
  if(window.__viewerDiagnostics)window.__viewerDiagnostics.modelsLoaded=idx+1;
  // Core vessels become visible as early as possible; the full anatomy still
  // loads automatically and remains the default final view as requested.
  applyFilters();invalidate();
  if(idx===1){
    if(vessels.length!==68)throw Error(`核心血管資料數量不符：${vessels.length}/68`);
    $('loading').hidden=true;
    $('statusText').textContent='已顯示核心血管，正在補入更多分支…';
    if(window.__viewerDiagnostics)window.__viewerDiagnostics.progressiveStage='core';
  }
  if(idx===3){
    if(vessels.length!==169)throw Error(`主要血管資料數量不符：${vessels.length}/169`);
    $('statusText').textContent='已顯示主要血管，正在補齊細分支…';
    if(window.__viewerDiagnostics)window.__viewerDiagnostics.progressiveStage='main';
  }
 }
 // Geometry existence is an explicit release condition; 643 names alone do not prove Draco decoded.
 if(vessels.length!==643)throw Error(`解剖模型構造數不符：${vessels.length} / 643`);
 let vertexCount=0;
 for(const ob of vessels){const a=ob.geometry?.getAttribute('position');if(!a||a.count<3)throw Error(`血管幾何解碼失敗：${ob.name}`);vertexCount+=a.count;}
 if(vertexCount<1000)throw Error('血管模型頂點異常偏少，請檢查 Draco 解碼');
 draco.dispose();applyFilters();if(!flowSlug&&!stagedFlow)frame();
 renderer.render(scene,camera);
 const triangles=renderer.info.render.triangles;
 if(triangles<1000)throw Error('WebGL 未成功繪製血管三角面');
 window.__viewerBootState='loaded';window.__v24ready=true;$('loading').hidden=true;applyFilters();
 if(window.__viewerDiagnostics)Object.assign(window.__viewerDiagnostics,{vertices:vertexCount,renderedTriangles:triangles,actualGlbGeometry:true});
 const pulmonary=byType.arteries.filter(x=>x.userData.info.type==='Pulmonary artery').length;
 const pvein=byType.veins.filter(x=>x.userData.info.type==='Pulmonary vein').length;
 $('diagnostics').textContent=`動脈 ${byType.arteries.length} 段／靜脈 ${byType.veins.length} 段。肺動脈分段 ${pulmonary}、肺靜脈分段 ${pvein}。漸進式模型合計 2.62 MB。`;
 if(window.__viewerDiagnostics){window.__viewerDiagnostics.organShells=organShells?.children.length||0;window.__viewerDiagnostics.organMode=organShells?.userData.organMode||'hidden';}if(window.__viewerDiagnostics){window.__viewerDiagnostics.vessels=vessels.length;window.__viewerDiagnostics.progressiveStage='complete';}notify('精細動靜脈模型已完整載入');
 }catch(err){errorStage(err);}}
// Read-only local QA snapshot; never enabled on the public classroom site.
if((location.hostname==='127.0.0.1'||location.hostname==='localhost')&&new URLSearchParams(location.search).has('qa')){
 window.__blood3dQa=Object.freeze({snapshot(){return {
  active:!!stagedFlow,index:stagedAt,elapsedMs:stagedMs,
  durationMs:stagedFlow?.[stagedAt]?.durationMs||0,count:stagedFlow?.length||0,
  playing:flowPlaying,marker:flowMarker?.position.toArray()||null,
  oxygen:stagedFlow?.[stagedAt]?.oxygen||null,
  kind:stagedFlow?.[stagedAt]?.kind||null,
  camera:camera?.position.toArray()||null,lookAt:controls?.target.toArray()||null,
  distance:controls?.getDistance()||null,cameraMinDistance:controls?.minDistance||null,
  savedExploreView:!!exploreBeforeDemo,exploreOriginalTier:exploreBeforeDemo?.level??null,
  savedExploreCamera:exploreBeforeDemo?.camera||null,savedExploreTarget:exploreBeforeDemo?.target||null,
  level,filterType,
  cameraMode:cameraMode(),outsideBody:camera?!isWithinBodyEnvelope(camera.position.toArray()):null,
  organMode:organShells?.userData.organMode||'hidden',organVisible:organShells?.visible||false,organMeshes:organShells?.children.filter(o=>o.isMesh).length||0,organOpacity:organShells?.children.find(o=>o.isMesh)?.material.opacity||0,
  organRims:organShells?.children.filter(o=>o.children.some(c=>c.userData.organRim)).length||0,
  heartOpacity:organShells?.children.find(o=>o.userData.organType==='heart')?.material.opacity||0,
  organLabelsVisible:!($('organLabels')?.hidden??true),bodyContextMeshes:bodyContext?.children.length||0,fullScenePlayback:!!(stagedFlow||flowSlug)&&!activeFitCorners,
  routeSelectOptions:[...($('from')?.options||[])].map(x=>x.textContent),
  organFocus:organShells?.userData.organFocus||'none',organLabelCount:[...($('organLabels')?.children||[])].filter(el=>!el.hidden).length,
  intercostalVisible:vessels.filter(o=>/intercostal/i.test(o.userData.info.name)&&o.visible).length,
  visibleVessels:vessels.filter(o=>o.visible).length,
  teachingForegroundVessels:vessels.filter(o=>o.userData.educationalForeground&&o.visible).length,
  fitCornerCount:activeFitCorners?.length||0,
  frameCoverage:activeFitCorners?.length?normalizedViewBounds(activeFitCorners,{
   target:controls.target.toArray(),direction:camera.position.clone().sub(controls.target).toArray(),
   distance:controls.getDistance(),fovDegrees:camera.fov,aspect:camera.aspect
  }).reduce((x,p)=>Math.max(x,Math.abs(p.x),Math.abs(p.y)),0):null
 };}});
}
// Background tabs are paused, not silently advanced; user resumes explicitly.
document.addEventListener('visibilitychange',()=>{
 if(document.hidden&&flowPlaying)stopFlow(false);
});
start();
