/* V0.45 — keep the current real vessels readable against translucent heart/lungs.
 * This is a DRAW ORDER rule only, NOT a change in vessel anatomy or physiology.
 * Solid organ shells preserve real occlusion; ordinary exploration is untouched. */
export function teachingForeground({organMode='hidden',pulmonary=false,selected=false,active=false,context=false}={}){
 return organMode==='translucent'&&pulmonary&&!selected&&(active||context);
}
export function teachingVesselStyle(foreground){
 return {transparent:!!foreground,opacity:1,depthTest:!foreground,
  depthWrite:!foreground,renderOrder:foreground?920:0};
}
