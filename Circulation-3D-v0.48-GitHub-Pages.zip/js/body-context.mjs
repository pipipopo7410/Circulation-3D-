/* V0.48: faint human location reference, not medical anatomy or a selectable body. */
import * as THREE from 'three';
const COLOR=0x8caec3;
function softenedMesh(geometry, name){
 const material=new THREE.MeshBasicMaterial({color:COLOR,transparent:true,opacity:.025,depthWrite:false,depthTest:true,side:THREE.DoubleSide});
 const mesh=new THREE.Mesh(geometry,material);mesh.name=name;mesh.renderOrder=-12;
 const outline=new THREE.ShaderMaterial({
  uniforms:{uColor:{value:new THREE.Color(0x6f99b0)},uOpacity:{value:.29}},
  vertexShader:`varying vec3 n;varying vec3 v;void main(){vec4 p=modelViewMatrix*vec4(position,1.);n=normalize(normalMatrix*normal);v=normalize(-p.xyz);gl_Position=projectionMatrix*p;}`,
  fragmentShader:`varying vec3 n;varying vec3 v;uniform vec3 uColor;uniform float uOpacity;void main(){float edge=1.-abs(dot(normalize(n),normalize(v)));float a=uOpacity*smoothstep(.54,.92,edge);gl_FragColor=vec4(uColor,a);}`,
  transparent:true,depthWrite:false,depthTest:true,side:THREE.DoubleSide
 });
 const rim=new THREE.Mesh(geometry,outline);rim.renderOrder=-11;mesh.add(rim);
 mesh.userData.contextOnly=true;return mesh;
}
function ellipsoid(name,pos,scale){const obj=softenedMesh(new THREE.SphereGeometry(1,18,12),name);obj.position.set(...pos);obj.scale.set(...scale);return obj;}
function limb(name,start,end,radius1,radius2){
 const a=new THREE.Vector3(...start),b=new THREE.Vector3(...end);
 const axis=b.clone().sub(a),len=axis.length();
 const geom=new THREE.CylinderGeometry(radius2,radius1,len,12,1,true);
 const obj=softenedMesh(geom,name);obj.position.copy(a).add(b).multiplyScalar(.5);
 obj.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),axis.normalize());return obj;
}
/** Human figure is approximately aligned with the existing vessel dimensions; its
 * rim is visual context only. It is never used for anatomy selection or camera limits. */
export function buildBodyContext(){
 const body=new THREE.Group();body.name='極淡人體定位輪廓';
 // Orientational shell: head, neck, narrowing waist, pelvis and tapered limbs.
 const parts=[
  ellipsoid('頭部',[0,1.592,.005],[.105,.128,.091]),
  ellipsoid('頸部',[0,1.452,.006],[.057,.052,.056]),
  ellipsoid('胸廓',[0,1.254,.002],[.237,.222,.133]),
  ellipsoid('腹部',[0,1.001,.005],[.168,.184,.111]),
  ellipsoid('骨盆',[0,.814,.008],[.175,.122,.117]),
 ];
 for(const sign of [-1,1]){
  parts.push(ellipsoid('肩膀',[sign*.231,1.353,.002],[.075,.074,.086]));
  parts.push(limb('上臂',[sign*.258,1.340,.007],[sign*.333,1.052,.013],.061,.045));
  parts.push(limb('前臂',[sign*.338,1.063,.015],[sign*.396,.842,.021],.046,.031));
  parts.push(ellipsoid('手掌',[sign*.406,.782,.024],[.042,.080,.027]));
  parts.push(limb('大腿',[sign*.098,.752,.008],[sign*.106,.471,.010],.090,.066));
  parts.push(ellipsoid('膝部',[sign*.106,.440,.009],[.068,.074,.071]));
  parts.push(limb('小腿',[sign*.108,.414,.010],[sign*.104,.115,.019],.065,.038));
  parts.push(ellipsoid('足部',[sign*.105,.060,.059],[.053,.042,.109]));
 }
 parts.forEach(o=>body.add(o));body.userData.educationalContext=true;
 return body;
}
