/* V0.47 — iPad pointer gestures and temporary classroom view restoration.
 * Pure functions: no DOM or Three.js dependency, so they can be tested offline. */
const finite = n => typeof n === 'number' && Number.isFinite(n);
const point = p => p && finite(p.x) && finite(p.y) && finite(p.t) && (typeof p.id === 'number' || typeof p.id === 'string');
export function createTapGate({maxDurationMs=430,maxMovePx=10}={}){
 if(!finite(maxDurationMs)||maxDurationMs<=0||!finite(maxMovePx)||maxMovePx<0)throw Error('Invalid tap limits');
 const active = new Map();
 let multiTouch = false;
 const makeEvent = e => ({id:e.id,x:e.x,y:e.y,t:e.t});
 return {
  down(event){
   const e=makeEvent(event);if(!point(e))return;
   if(active.size===0)multiTouch=false;
   active.set(e.id,{...e,valid:true});
   if(active.size>1)multiTouch=true;
  },
  move(event){
   const e=makeEvent(event);if(!point(e))return;
   const first=active.get(e.id);if(first && Math.hypot(e.x-first.x,e.y-first.y)>maxMovePx)first.valid=false;
  },
  up(event){
   const e=makeEvent(event);if(!point(e))return false;
   const first=active.get(e.id);if(!first)return false;
   active.delete(e.id);
   const tap = !multiTouch && active.size===0 && first.valid && e.t>=first.t && e.t-first.t<=maxDurationMs && Math.hypot(e.x-first.x,e.y-first.y)<=maxMovePx;
   if(active.size===0)multiTouch=false;
   return tap;
  },
  cancel(id){if(active.has(id)){active.delete(id);multiTouch=true;if(active.size===0)multiTouch=false;}},
  reset(){active.clear();multiTouch=false;},
  get activeCount(){return active.size;}
 };
}
const vec=v=>Array.isArray(v)&&v.length===3&&v.every(finite);
const allowed=new Set(['all','arteries','veins']);
export function snapshotExploration({camera,target,level,filterType}){
 if(!vec(camera)||!vec(target)||![0,1,2].includes(level)||!allowed.has(filterType))throw Error('Invalid exploration view');
 return {camera:[...camera],target:[...target],level,filterType,manuallyChangedFilter:false};
}
export function resolveExplorationFilter(saved){
 if(!saved||![0,1,2].includes(saved.level)||!allowed.has(saved.filterType))throw Error('Invalid saved view');
 return saved.manuallyChangedFilter ? null : {level:saved.level,filterType:saved.filterType};
}

/**
 * Restore an exploration pose without carrying the previous OrbitControls
 * rotation / pan inertia into the teacher's saved camera position.
 * Flushing BEFORE applying the pose matters: turning damping off consumes any
 * pending internal sphericalDelta and panOffset in a single update.
 * Uses the existing OrbitControls API; no private Three.js fields are touched.
 */
export function restoreCameraPoseSafely({controls,camera,pose,minDistance=1.88}){
 if(!controls||typeof controls.update!=='function'||!camera||!pose||!vec(pose.camera)||!vec(pose.target))
  throw Error('Invalid OrbitControls camera restore arguments');
 if(!finite(minDistance)||minDistance<=0)throw Error('Invalid camera minimum');
 const damping=controls.enableDamping;
 try{
  controls.enableDamping=false;
  controls.update(); // consume residual movement *before* setting the saved pose
  controls.minDistance=minDistance;
  controls.target.set(...pose.target);
  camera.position.set(...pose.camera);
  controls.update(); // synchronize OrbitControls without inertia
 }finally{
  controls.enableDamping=damping;
 }
}
