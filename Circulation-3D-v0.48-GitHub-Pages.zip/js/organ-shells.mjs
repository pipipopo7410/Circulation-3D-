/* V0.44 heart & lung visualization layer: intentionally simplified anatomy.
 * The meshes are NOT source GLBs and never substitute for blood vessel paths. */
import * as THREE from 'three';
import {makeLung,makeHeart,lungSurfacePoint,ORGAN_LANDMARKS,organOpacityFor} from './organ-shapes.mjs';

export const ORGAN_MODES=['translucent','solid','hidden'];
export const ORGAN_FOCUS=['none','heart','right-lung','left-lung'];
export const ORGAN_MODE_LABELS={translucent:'器官：半透明',solid:'器官：實體',hidden:'器官：隱藏'};
export function nextOrganMode(current){return ORGAN_MODES[(ORGAN_MODES.indexOf(current)+1)%ORGAN_MODES.length]||ORGAN_MODES[0];}
function makeMesh(raw,color,name,organType){
 const geometry=new THREE.BufferGeometry();
 geometry.setAttribute('position',new THREE.Float32BufferAttribute(raw.positions,3));
 geometry.setIndex(raw.indices);geometry.computeVertexNormals();
 const material=new THREE.MeshLambertMaterial({
  color,side:THREE.FrontSide,transparent:true,opacity:organType==='heart'?.74:.48,
  depthWrite:false,depthTest:true,
  emissive:color,emissiveIntensity:.07
 });
 const mesh=new THREE.Mesh(geometry,material);
 mesh.name=name+'（國中教學簡化器官外形，非真實解剖掃描）';
 mesh.userData.educationalApproximation=true;
 mesh.userData.organShell=true;
 mesh.userData.organType=organType;
 // V0.44: a soft *view-dependent silhouette*, not a dense mesh wireframe.
 // Stronger borders are visible without hiding vessels through the organ.
 const rimMaterial=new THREE.ShaderMaterial({
  uniforms:{uColor:{value:new THREE.Color(color).multiplyScalar(.58)},uOpacity:{value:organType==='heart'?.86:.73}},
  vertexShader:`varying vec3 vNormal; varying vec3 vView;
   void main(){vec4 mv=modelViewMatrix*vec4(position,1.0);
    vNormal=normalize(normalMatrix*normal);vView=normalize(-mv.xyz);
    gl_Position=projectionMatrix*mv;}`,
  fragmentShader:`varying vec3 vNormal; varying vec3 vView;
   uniform vec3 uColor; uniform float uOpacity;
   void main(){float f=1.0-abs(dot(normalize(vNormal),normalize(vView)));
    float alpha=uOpacity*smoothstep(.38,.84,f);
    gl_FragColor=vec4(uColor,alpha);}`,
  side:THREE.FrontSide,transparent:true,depthWrite:false,depthTest:true,
  polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1
 });
 const rim=new THREE.Mesh(geometry,rimMaterial);
 rim.name=name+'輪廓增強（教學外殼）';
 rim.renderOrder=10;
 rim.userData.organRim=true;
 mesh.add(rim);
 return mesh;
}

export function buildOrganShells(){
 const group=new THREE.Group();group.name='V0.44 心肺器官定位外殼（教學簡化）';
 const right=makeMesh(makeLung('right'),0xe0abb8,'右肺','lung');
 const left=makeMesh(makeLung('left'),0xe8b3be,'左肺（心切跡）','lung');
 const heart=makeMesh(makeHeart(),0xb53c5a,'心臟','heart');
 right.userData.organSide='right';left.userData.organSide='left';
 for(const m of [right,left,heart])group.add(m);
 // Gentle surface fissures: right lung has three lobes, left lung has two.
 // Guide lines are classroom cues, not high-resolution anatomical boundaries.
 for(const side of ['right','left']){
  const fissures=side==='right'?[t=>.64+.015*Math.cos(t*3),t=>.74-.48*t/Math.PI]:[t=>.73-.45*t/Math.PI];
  for(const fissure of fissures){
   const pts=[];
   for(let i=0;i<=36;i++){
    const a=.30+(Math.PI-.60)*i/36;
    const p=lungSurfacePoint(side,fissure(a),a);p[2]+=.0015;pts.push(new THREE.Vector3(...p));
   }
   const geometry=new THREE.BufferGeometry().setFromPoints(pts);
   const line=new THREE.Line(geometry,new THREE.LineBasicMaterial({color:0x97656e,transparent:true,opacity:.36,depthWrite:false}));
   line.name=(side==='right'?'右肺':'左肺')+'葉間裂概念線';
   line.userData.organShell=true;line.userData.organFissure=true;line.userData.educationalApproximation=true;
   group.add(line);
  }
 }
 // Atrial bulges are only visual contours. The existing lesson separately
 // represents the FOUR chambers and retains full physiological priority.
 const lobes=[[-.012,1.347,.079,.020,.021,.025],[.030,1.346,.081,.020,.019,.023]];
 for(const [x,y,z,rx,ry,rz] of lobes){
  const lump=new THREE.Mesh(new THREE.SphereGeometry(1,24,18),heart.material.clone());
  lump.position.set(x,y,z);lump.scale.set(rx,ry,rz);
  lump.name='心臟上緣輪廓（示意）';lump.userData.educationalApproximation=true;lump.userData.organShell=true;lump.userData.organType='heart';
  group.add(lump);
 }
 group.userData.organMode='translucent';
 group.userData.organFocus='none';
 group.userData.organLandmarks=ORGAN_LANDMARKS;
 setOrganShellMode(group,'translucent');
 return group;
}
export function setOrganShellMode(group,mode){
 if(!group||!ORGAN_MODES.includes(mode))throw Error('Unknown organ mode: '+mode);
 group.visible=mode!=='hidden';
 for(const mesh of group.children){
  const mat=mesh.material;
  mat.transparent=mode==='translucent'||!!mesh.userData.organFissure;
  mat.opacity=mesh.userData.organFissure?(mode==='translucent'?.28:.42):(mode==='translucent'?(mesh.userData.organType==='heart'?.74:.48):1);
  mat.depthWrite=mesh.userData.organFissure?false:mode==='solid';
  mat.needsUpdate=true;
  // Keep an organ outline visible without compromising the blood flow dot.
  for(const child of mesh.children){
   if(!child.userData.organRim)continue;
   child.visible=mode!=='hidden';
   child.material.uniforms.uOpacity.value=mode==='translucent'?(mesh.userData.organType==='heart'?.86:.73):.38;
  }
 }
 group.userData.organMode=mode;
 // Keep user-selected solid/hidden modes intact; only the translucent teaching
 // overlay is allowed to change the relative emphasis of organ surfaces.
 applyOrganFocus(group);
}

function applyOrganFocus(group){
 const active=group.userData.organMode==='translucent' ? (group.userData.organFocus||'none') : 'none';
 for(const mesh of group.children){
  const mat=mesh.material;
  if(!mat||mesh.userData.organFissure)continue;
  const type=mesh.userData.organType;
  const key=type==='heart'?'heart':mesh.userData.organSide==='right'?'right-lung':'left-lung';
  if(group.userData.organMode==='translucent'){
   // Preserve both vessel visibility and recognisable organs. The attention
   // difference is intentionally subtle; no anatomical meaning is encoded.
   mat.opacity=organOpacityFor('translucent',type,key,active);
  }
  for(const child of mesh.children){
   if(!child.userData.organRim)continue;
   child.material.uniforms.uOpacity.value=group.userData.organMode==='translucent'
    ? (active==='none'?(type==='heart'?.86:.73):(key===active?.94:.62)) : .38;
  }
 }
}
export function setOrganShellFocus(group,focus='none'){
 if(!group||!ORGAN_FOCUS.includes(focus))throw Error('Unknown organ focus: '+focus);
 group.userData.organFocus=focus;
 applyOrganFocus(group);
}
