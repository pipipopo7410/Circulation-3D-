/* V0.44 — project small teaching labels without masking each other or UI.
 * Pure UI geometry: no added anatomical content and no dependency on WebGL. */
export function positionVisibleLabels(labels,{width,height,focus='none'}={}){
 if(!(width>0&&height>0))return [];
 const priorities={heart:2,right:1,left:0};
 const selected=focus==='heart'?'heart':focus==='right-lung'?'right':focus==='left-lung'?'left':null;
 const sorted=[...labels].sort((a,b)=>
   (Number(b.id===selected)-Number(a.id===selected))||((priorities[b.id]??0)-(priorities[a.id]??0)));
 const placed=[];
 for(const item of sorted){
  const {x,y,z}=item;
  if(![x,y,z].every(Number.isFinite)||z<=-1||z>=1)continue;
  // Header/actions occupy the first part of the scene; status occupies bottom.
  if(x<33||x>width-33||y<68||y>height-37)continue;
  // Avoid the lesson cue (left upper corner) when present in a close-up.
  if(item.cueVisible&&x<Math.min(235,width*.48)&&y<154)continue;
  if(placed.some(p=>Math.abs(p.x-x)<64&&Math.abs(p.y-y)<28))continue;
  placed.push({id:item.id,x,y,focused:item.id===selected});
 }
 return placed;
}
