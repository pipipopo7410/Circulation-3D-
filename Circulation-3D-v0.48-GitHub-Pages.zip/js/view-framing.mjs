/* V0.45 — camera-angle-aware lesson/route framing (pure geometry, no WebGL).
 * Recalculate only when a lesson opens or the viewport changes, never per frame.
 * Points are original vessel-centreline/organ-envelope coordinates. */
const finite=v=>Array.isArray(v)&&v.length===3&&v.every(Number.isFinite);
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const cross=(a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const subtract=(a,b)=>a.map((x,i)=>x-b[i]);
const length=v=>Math.hypot(...v);
const unit=(v,alternate=[0,0,1])=>{
 const n=length(v);return n>1e-9?v.map(x=>x/n):alternate;
};
export function cornersFromBounds(min,max){
 if(!finite(min)||!finite(max)||min.some((x,i)=>x>max[i]))throw Error('Invalid bounds');
 return [min[0],max[0]].flatMap(x=>[min[1],max[1]].flatMap(y=>[min[2],max[2]].map(z=>[x,y,z])));
}
export function centerOfBounds(points){
 if(!Array.isArray(points)||!points.length||points.some(p=>!finite(p)))throw Error('Invalid fit points');
 const min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
 for(const p of points)for(let i=0;i<3;i++){min[i]=Math.min(min[i],p[i]);max[i]=Math.max(max[i],p[i]);}
 return min.map((v,i)=>(v+max[i])/2);
}
export function fitDistanceForView(points,{target,direction=[0,0,1],fovDegrees=36,aspect=1,padding=1.3,minimum=0}={}){
 if(!finite(target)||!finite(direction)||!Number.isFinite(aspect)||aspect<=0||!Number.isFinite(fovDegrees)||fovDegrees<=0||fovDegrees>=160||padding<1)throw Error('Invalid camera fit');
 const forward=unit(direction),worldUp=[0,1,0];
 const right=unit(cross(worldUp,forward),[1,0,0]);
 const up=unit(cross(forward,right),[0,1,0]);
 const verticalTan=Math.tan(fovDegrees*Math.PI/360);
 const horizontalTan=verticalTan*aspect;
 // For each bbox corner, camera depth is distance - dot(relative,forward).
 // Allow for both depth and horizontal/vertical perspective expansion.
 let needed=Math.max(.01,minimum);
 for(const p of points){
  if(!finite(p))throw Error('Invalid fit point');
  const r=subtract(p,target),depth=dot(r,forward);
  needed=Math.max(needed,depth+Math.abs(dot(r,right))*padding/horizontalTan,
   depth+Math.abs(dot(r,up))*padding/verticalTan,depth+.015);
 }
 return needed;
}
export function normalizedViewBounds(points,{target,direction=[0,0,1],distance,fovDegrees=36,aspect=1}={}){
 const forward=unit(direction),right=unit(cross([0,1,0],forward),[1,0,0]);
 const up=unit(cross(forward,right),[0,1,0]);
 const tan=Math.tan(fovDegrees*Math.PI/360);
 return points.map(p=>{
  const r=subtract(p,target),depth=distance-dot(r,forward);
  return {x:dot(r,right)/(depth*tan*aspect),y:dot(r,up)/(depth*tan),depth};
 });
}
