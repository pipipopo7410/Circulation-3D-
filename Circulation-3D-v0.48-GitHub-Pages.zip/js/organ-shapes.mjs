/* V0.44 — classroom organ silhouettes in original GLB coordinates (metres).
 * Deliberately simplified anatomical envelopes, NOT patient-specific scans.
 * Pure geometry / landmark module; safe to test in Node without WebGL. */
export const ORGAN_LANDMARKS=Object.freeze({
  heart:{center:[0.023,1.303,0.056],superiorY:1.367,apexY:1.225},
  rightLung:{center:[-0.081,1.319,-0.030],baseY:1.198,apexY:1.445},
  leftLung:{center:[0.080,1.319,-0.030],baseY:1.207,apexY:1.440},
  // Control landmarks come from cardiopulmonary-stages.json, not a new anatomy source.
  rightPulmonaryArteryTip:[-.034,1.331,-.007],
  rightPulmonaryVeinStart:[-.044,1.338,.002],
  aortaStart:[.020,1.316,.019],
  superiorVenaCavaEnd:[-.017,1.341,.018]
});

const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
function profile(t,points){
 for(let i=1;i<points.length;i++)if(t<=points[i][0]){
  const [a,av]=points[i-1],[b,bv]=points[i];const u=clamp((t-a)/(b-a),0,1);const smooth=u*u*(3-2*u);
  return av+(bv-av)*smooth;
 }
 return points[points.length-1][1];
}
function meshOfSections(section,{rings=36,radial=48}={}){
 const positions=[],indices=[];
 for(let i=0;i<=rings;i++){
  const t=i/rings;
  for(let j=0;j<radial;j++){
   const theta=j*2*Math.PI/radial;
   positions.push(...section(t,theta));
  }
 }
 for(let i=0;i<rings;i++)for(let j=0;j<radial;j++){
  const a=i*radial+j,b=i*radial+(j+1)%radial,c=(i+1)*radial+j,d=(i+1)*radial+(j+1)%radial;
  indices.push(a,c,d,a,d,b);
 }
 // Caps: close the lung base and the heart's broad superior base.
 const bottom=positions.length/3;
 const bottomRing=Array.from({length:radial},(_,i)=>positions.slice(i*3,i*3+3));
 const topRing=Array.from({length:radial},(_,i)=>positions.slice((rings*radial+i)*3,(rings*radial+i)*3+3));
 const centroid=ring=>ring.reduce((p,v)=>p.map((x,k)=>x+v[k]/radial),[0,0,0]);
 positions.push(...centroid(bottomRing));const top=positions.length/3;positions.push(...centroid(topRing));
 for(let i=0;i<radial;i++){
  const j=(i+1)%radial;
  indices.push(bottom,i,j); // underside normal -Y
  indices.push(top,rings*radial+j,rings*radial+i); // upper normal +Y
 }
 return {positions,indices};
}
// A recognisable *teaching* outline: tapering apex, broad diaphragm-facing
// base, a left cardiac notch, and slight side-to-side asymmetry. All lengths
// are in the coordinate system of the existing (unchanged) vessel GLBs.
export function lungSurfacePoint(side,t,theta){
 if(!['right','left'].includes(side))throw Error('Unknown lung side');
 const right=side==='right',sign=right?-1:1;
 const center=right?-.081:.080;
 const base=right?1.198:1.207,top=right?1.445:1.440;
 const rx=right?.078:.073,rz=right?.057:.054;
 // Wider below, distinctly tapered above — the earlier profile looked
 // columnar at classroom projection distances.
 const breadth=profile(t,[[0,.69],[.06,.85],[.17,1.04],[.34,1.07],[.52,.96],[.70,.72],[.84,.43],[.96,.14],[1,.052]]);
 let x=Math.cos(theta)*rx*breadth;
 // Carve the left heart-facing indentation mainly into the anterior-medial
 // surface, rather than falsely depicting a missing entire lung lobe.
 const medial=x*sign<0;
 if(medial){
  const notch=(right?.15:.72)*Math.exp(-Math.pow((t-(right?.55:.51))/.19,2));
  const anteriorBias=.65+.35*Math.max(0,Math.sin(theta));
  x*=1-notch*anteriorBias;
 }
 const sway=sign*(.007-.010*t);
 // A slightly curved basal border follows the general diaphragmatic dome.
 // No detailed pleural anatomy is claimed.
 const basalCurve=Math.pow(1-t,6)*(.009*Math.sin(theta)+.004*Math.cos(theta));
 const y=base+(top-base)*t+basalCurve;
 const z=-.032+.009*t+Math.sin(theta)*rz*breadth;
 return [center+sway+x,y,z];
}
export function makeLung(side){
 return meshOfSections((t,theta)=>lungSurfacePoint(side,t,theta),{rings:42,radial:56});
}
export function makeHeart(){
 const base=ORGAN_LANDMARKS.heart.apexY,top=ORGAN_LANDMARKS.heart.superiorY;
 return meshOfSections((t,theta)=>{
  // A tilted pear-shaped volume (broad base, narrow left-pointing apex), not
  // a straight cylinder or an accurate four-chamber cavity reconstruction.
  const width=profile(t,[[0,.055],[.1,.28],[.24,.60],[.43,.90],[.61,1.07],[.78,1.06],[.92,.86],[1,.65]]);
  const x=.066-.062*t+Math.cos(theta)*.051*width;
  const y=base+(top-base)*t+.002*Math.cos(theta)*Math.sin(Math.PI*t);
  const forward=Math.sin(theta);
  const z=.072-.018*t+forward*.043*width*(forward<0?.76:1);
  return [x,y,z];
 },{rings:42,radial:56});
}
/* Lightweight visual emphasis only — not an oxygen measurement or a
 * true tissue reflectance model. Pure data for release-guard tests. */
export function organOpacityFor(mode,type,key,focus='none'){
 if(!['solid','hidden','translucent'].includes(mode))throw Error('Unknown organ mode');
 if(mode!=='translucent')return 1;
 if(focus==='none')return type==='heart'?.74:.48;
 const active=key===focus;
 return type==='heart'?(active?.80:.61):(active?.60:.42);
}

export function positionBounds(mesh){
 const out={min:[Infinity,Infinity,Infinity],max:[-Infinity,-Infinity,-Infinity]};
 for(let i=0;i<mesh.positions.length;i+=3)for(let k=0;k<3;k++){
  const x=mesh.positions[i+k];out.min[k]=Math.min(out.min[k],x);out.max[k]=Math.max(out.max[k],x);
 }
 return out;
}
