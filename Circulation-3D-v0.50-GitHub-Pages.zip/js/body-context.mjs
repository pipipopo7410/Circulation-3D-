/* V0.50 — actual volumetric transparent human context layer.
 * The sealed skin surface is a blended 3D teaching approximation, NOT a
 * medical scan. It follows vascular XYZ coordinates (Y-up), unlike the
 * previous V0.49 flat XY shape extrusion. Original vessels are unchanged.
 */
import * as THREE from 'three';

export function buildBodyContext() {
  const group = new THREE.Group();
  group.name = '半透明三維人體定位外殼';
  group.userData.educationalContext = true;
  group.userData.bodyGeometryType = 'closed-volume-3d';
  return group;
}

/** Attach a fully formed, watertight XYZ surface from models/human-body-context.glb. */
export function attachBodyContext(group, gltfScene) {
  if (!group || !gltfScene) throw Error('Body context: mesh container missing');
  let count = 0;
  const surfaceMaterial = new THREE.MeshPhongMaterial({
    color:0xc8e7f1,
    specular:0xe0f4ff,
    shininess:42,
    transparent:true,
    opacity:.067,
    side:THREE.FrontSide,
    depthWrite:false,
    depthTest:true
  });
  const outlineMaterial = new THREE.ShaderMaterial({
    uniforms:{
      uColor:{value:new THREE.Color(0x6a9eb6)},
      uEdge:{value:.28}
    },
    vertexShader:`varying vec3 vNormal;varying vec3 vView;
      void main(){vec4 eye=modelViewMatrix*vec4(position,1.0);
      vNormal=normalize(normalMatrix*normal);
      vView=normalize(-eye.xyz);
      gl_Position=projectionMatrix*eye;}`,
    fragmentShader:`varying vec3 vNormal;varying vec3 vView;
      uniform vec3 uColor;uniform float uEdge;
      void main(){float f=1.0-abs(dot(normalize(vNormal),normalize(vView)));
      float alpha=uEdge*pow(clamp(f,0.0,1.0),2.25);
      gl_FragColor=vec4(uColor,alpha);}`,
    transparent:true,
    depthWrite:false,
    depthTest:true,
    side:THREE.FrontSide
  });
  const originalMeshes=[];
  gltfScene.traverse(node=>{if(node.isMesh)originalMeshes.push(node);});
  for (const node of originalMeshes) {
    if (!node.geometry || node.geometry.getAttribute('position')?.count < 1000)
      throw Error('Body context: missing 3D vertices');
    // The exported teaching GLB carries XYZ positions and indices; generate
    // smooth surface normals before Phong shading / Fresnel transparency.
    if (!node.geometry.getAttribute('normal')) node.geometry.computeVertexNormals();
    const position=node.geometry.getAttribute('position');
    const box=new THREE.Box3().setFromBufferAttribute(position);
    // Reject another thin front/back extrusion before it reaches the student.
    const thickness=box.max.z-box.min.z;
    if (thickness<.30) throw Error('Body context: shell is unexpectedly flat');
    node.material?.dispose?.();node.material=surfaceMaterial;
    node.renderOrder=-14;
    node.name='連續三維透明人體皮膚';
    node.userData.contextOnly=true;
    const rim=new THREE.Mesh(node.geometry,outlineMaterial);
    rim.name='依視角變化的立體人體輪廓';
    rim.renderOrder=-13;
    rim.userData.contextOnly=true;
    node.add(rim);
    count++;
  }
  if(count<1)throw Error('Body context: no surface mesh');
  group.clear();group.add(gltfScene);
  group.userData.surfaceMeshes=count;
  group.userData.modelLoaded=true;
  return group;
}
