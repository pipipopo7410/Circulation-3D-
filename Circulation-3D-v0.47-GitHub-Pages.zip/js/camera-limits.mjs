/* V0.40: classroom camera guard. Units and axes follow the existing source GLBs.
 * This transparent safety envelope is NOT a new anatomical model.
 * It keeps the camera outside the teaching silhouette, not a physics collider. */
export const CAMERA_RULES = Object.freeze({
  explore: {floor:2.25},        // whole-body discovery: no close-range tunnel view
  lesson:  {floor:1.06},       // teacher-led: closer, still outside chest/limbs
  route:   {floor:1.18},       // single-vessel preview: show the surrounding anatomy
  target: {x:[-.56,.56], y:[.12,1.59], z:[-.18,.18]},
  envelope: {center:[0,.8524569,.0117921], radius:[.63,1.06,.41]},
  clearance:.13
});
const clip=(n,lo,hi)=>Math.max(lo,Math.min(hi,n));
export function clampLookAt(target){
 if(!Array.isArray(target)||target.length!==3||!target.every(Number.isFinite))throw Error('Invalid camera target');
 const t=CAMERA_RULES.target;
 return [clip(target[0],...t.x),clip(target[1],...t.y),clip(target[2],...t.z)];
}
export function isWithinBodyEnvelope(position){
 const {center,radius}=CAMERA_RULES.envelope;
 return position.reduce((s,v,i)=>s+((v-center[i])/radius[i])**2,0)<1;
}
// Starting at lookAt and following direction toward the camera, find the
// farthest intersection with a protective ellipsoid. Outside means > exit+gap.
export function minimumOutsideDistance(target,unitDirection){
 const {center,radius}=CAMERA_RULES.envelope;
 let A=0,B=0,C=-1;
 for(let i=0;i<3;i++){
  const a=(target[i]-center[i])/radius[i], b=unitDirection[i]/radius[i];
  A+=b*b; B+=2*a*b; C+=a*a;
 }
 const discriminant=B*B-4*A*C;
 if(discriminant<0)return 0;
 const exit=(-B+Math.sqrt(Math.max(0,discriminant)))/(2*A);
 return exit>0?exit+CAMERA_RULES.clearance:0;
}
export function protectCameraPose(camera,target,{mode='explore',lessonFit=0}={}){
 if(!CAMERA_RULES[mode])throw Error('Unknown camera mode: '+mode);
 if(!Array.isArray(camera)||camera.length!==3||!camera.every(Number.isFinite))throw Error('Invalid camera position');
 const nextTarget=clampLookAt(target);
 // Translate both camera and look-at when an excessive pan is clamped:
 // this preserves viewing direction and avoids camera-rotation jumps.
 const adjustedCamera=camera.map((v,i)=>v+nextTarget[i]-target[i]);
 const offset=adjustedCamera.map((v,i)=>v-nextTarget[i]);
 const distance=Math.hypot(...offset);
 const unit=distance>1e-8?offset.map(v=>v/distance):[0,0,1];
 const lessonFloor=mode==='lesson'?Math.max(CAMERA_RULES.lesson.floor,Math.min(1.95,lessonFit*.82)):0;
 const floor=Math.max(CAMERA_RULES[mode].floor,lessonFloor);
 const minimumDistance=Math.max(floor,minimumOutsideDistance(nextTarget,unit));
 const nextDistance=Math.max(distance,minimumDistance);
 const nextCamera=nextTarget.map((v,i)=>v+unit[i]*nextDistance);
 return {camera:nextCamera,target:nextTarget,minimumDistance,
  restricted:Math.abs(nextDistance-distance)>1e-7||nextTarget.some((v,i)=>Math.abs(v-target[i])>1e-7)};
}
